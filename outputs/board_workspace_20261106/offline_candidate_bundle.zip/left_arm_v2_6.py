#!/usr/bin/env python3
"""Clean left-arm bring-up controller v2.6.

This v2 controller intentionally does not import or reuse the old
left_arm_controller / teach_left_arm motion stack. It is for post-reassembly
bring-up: read status, low-gain holds, capture a new home, small nudges, and
low-gain home moves.

v2.6 keeps the stable v2.6 clearance/home motion layout, then centralizes
low-shoulder hold/active torque rules so new poses need less manual tuning.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import time
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Set, Tuple

import serial
from DM_CAN import DM_Motor_Type, Motor, MotorControl
from left_arm_v3_1_motion_dynamics import (
    configured_model, begin_motion, prepare_frame, send_command, finish_motion, reference_derivatives,
)


SERIAL_PORT = "/dev/ttyACM0"
SERIAL_BAUD = 921600
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
HOME_PATH = os.path.join(SCRIPT_DIR, "data", "left_arm_v2_home.json")
TABLE_CLEARANCE_PATH = os.path.join(SCRIPT_DIR, "data", "left_arm_v2_table_clearance.json")
CLAW_HOME_PATH = os.path.join(SCRIPT_DIR, "data", "left_arm_v2_claw_home.json")
ADAPTIVE_HOLD_TAU_PATH = os.path.join(SCRIPT_DIR, "data", "left_arm_v2_6_adaptive_hold_tau.json")
ADAPTIVE_ACTIVE_TAU_PATH = os.path.join(SCRIPT_DIR, "data", "left_arm_v2_6_adaptive_active_tau.json")
ADAPTIVE_TARGET_BIAS_PATH = os.path.join(SCRIPT_DIR, "data", "left_arm_v2_6_adaptive_target_bias.json")
ADAPTIVE_HOLD_TARGET_BIAS_PATH = os.path.join(SCRIPT_DIR, "data", "left_arm_v2_6_adaptive_hold_target_bias.json")


@dataclass(frozen=True)
class JointSpec:
    name: str
    motor_type: DM_Motor_Type
    slave_id: int
    master_id: int


JOINTS = [
    JointSpec("shoulder_front", DM_Motor_Type.DM4340, 0x1E, 0x0E),
    JointSpec("shoulder_side", DM_Motor_Type.DM4340, 0x1F, 0x0F),
    JointSpec("shoulder_rotate", DM_Motor_Type.DM4310, 0x20, 0x10),
    JointSpec("elbow", DM_Motor_Type.DM4340, 0x21, 0x11),
    JointSpec("arm_roll", DM_Motor_Type.DM4310, 0x22, 0x12),
    JointSpec("wrist_side", DM_Motor_Type.DM4310, 0x2A, 0x1A),
    JointSpec("wrist", DM_Motor_Type.DM4310, 0x29, 0x19),
]
CLAW_SPEC = JointSpec("claw", DM_Motor_Type.DM4310, 0x28, 0x18)
ALL_MOTOR_SPECS = JOINTS + [CLAW_SPEC]

DEFAULT_JOINTS = [spec.name for spec in JOINTS]
DEFAULT_HOME_ORDER = [
    "elbow",
    "shoulder_front",
    "shoulder_side",
    "shoulder_rotate",
    "wrist",
    "wrist_side",
    "arm_roll",
]

DEFAULT_CLEARANCE_ORDER = [
    "shoulder_front",
    "shoulder_side",
    "elbow",
    "shoulder_rotate",
    "arm_roll",
    "wrist_side",
    "wrist",
]

PREHOME_CLEARANCE_ORDER = [
    "wrist",
    "wrist_side",
    "arm_roll",
    "elbow",
    "shoulder_rotate",
    "shoulder_side",
    "shoulder_front",
]

OLD_HOME_ORDER = [
    "wrist",
    "wrist_side",
    "elbow",
    "shoulder_front",
    "shoulder_side",
    "shoulder_rotate",
    "arm_roll",
]

# DM_CAN historically failed to clamp its 12-bit MIT kd field. Values above
# 5.0 wrapped on the wire, so the arm was physically tuned with much smaller
# effective damping: 6.0->1.0, 6.2->1.2, 6.5->1.5, and 7.0->2.0.  The driver
# now clamps correctly; the tables below retain those measured on-wire gains.
HOME_GAINS = {
    "wrist": {"kp": 22.0, "kd": 1.4, "seconds": 5.0},
    "wrist_side": {"kp": 16.0, "kd": 2.2, "seconds": 6.0},
    "elbow": {"kp": 70.0, "kd": 3.0, "seconds": 6.0},
    "arm_roll": {"kp": 18.0, "kd": 1.0, "seconds": 12.0},
    "shoulder_front": {"kp": 90.0, "kd": 4.0, "seconds": 6.0},
    "shoulder_side": {"kp": 70.0, "kd": 3.0, "seconds": 6.0},
    "shoulder_rotate": {"kp": 24.0, "kd": 4.5, "seconds": 8.0},
}

HOME_HOLD_GAINS = {
    "wrist": {"kp": 18.0, "kd": 1.4},
    "wrist_side": {"kp": 18.0, "kd": 1.4},
    "arm_roll": {"kp": 32.0, "kd": 3.0},
    "elbow": {"kp": 65.0, "kd": 4.5},
    "shoulder_front": {"kp": 75.0, "kd": 5.0},
    "shoulder_side": {"kp": 65.0, "kd": 4.5},
    "shoulder_rotate": {"kp": 24.0, "kd": 4.0},
}

HOME_BASE_HOLD_GAINS = {
    "wrist": {"kp": 6.0, "kd": 0.8},
    "wrist_side": {"kp": 6.0, "kd": 0.8},
    "arm_roll": {"kp": 10.0, "kd": 2.0},
    "elbow": {"kp": 20.0, "kd": 3.0},
    "shoulder_front": {"kp": 25.0, "kd": 4.0},
    "shoulder_side": {"kp": 16.0, "kd": 2.5},
    "shoulder_rotate": {"kp": 10.0, "kd": 2.5},
}

HOME_JOINT_DEADBANDS_DEG = {
    "arm_roll": 3.0,
    "shoulder_rotate": 3.0,
}

HOME_COMPLIANT_HOLD_GAINS = {
    "arm_roll": {"kp": 4.0, "kd": 1.0},
    "shoulder_rotate": {"kp": 6.0, "kd": 5.0},
}

HOME_COMPLIANT_HOLDS_BY_ACTIVE = {
    "wrist": {"arm_roll", "shoulder_rotate"},
    "wrist_side": {"arm_roll", "shoulder_rotate"},
    "shoulder_rotate": {"arm_roll"},
}

COUPLED_HOME_MOVE_GAINS = {
    "elbow": {"kp": 65.0, "kd": 1.5},
    "shoulder_front": {"kp": 75.0, "kd": 2.0},
    "shoulder_side": {"kp": 65.0, "kd": 4.5},
    "arm_roll": {"kp": 18.0, "kd": 1.0},
    "wrist_side": {"kp": 16.0, "kd": 2.2},
    "wrist": {"kp": 22.0, "kd": 1.4},
}

COUPLED_HOME_MAX_SECONDS = 16.0
COUPLED_HOME_CONTROL_DT = 0.01
COUPLED_HOME_TRAJECTORY = "blend_smootherstep"
COUPLED_HOME_LINEAR_BLEND = 0.35
COUPLED_HOME_COMMAND_BIAS_DEG = {
    "shoulder_side": 1.0,
}
COUPLED_HOME_PROGRESS_WINDOWS = {
    "arm_roll": (0.65, 1.0),
    "wrist": (0.35, 1.0),
}
COUPLED_HOME_PRE_WINDOW_GAINS = {
    "wrist": {"kp": 6.0, "kd": 0.8},
}

CLEARANCE_JOINT_DEADBANDS_DEG = {
    "shoulder_rotate": 180.0,
}

CLEARANCE_MOVE_GAINS = {
    "wrist": {"kp": 24.0, "kd": 4.4},
    "wrist_side": {"kp": 22.0, "kd": 1.4},
    "arm_roll": {"kp": 50.0, "kd": 3.0},
    "elbow": {"kp": 95.0, "kd": 4.0},
    "shoulder_front": {"kp": 110.0, "kd": 5.0},
    "shoulder_side": {"kp": 80.0, "kd": 3.5},
    "shoulder_rotate": {"kp": 24.0, "kd": 4.5},
}

CLEARANCE_MOVE_SECONDS = {
    "shoulder_rotate": 8.0,
    "wrist": 24.0,
}

CLEARANCE_CONTINUOUS_JOINTS = {
    "wrist",
}

CLEARANCE_VELOCITY_FF_JOINTS = {
    "wrist",
}

COUPLED_CLEARANCE_MOVE_GAINS = {
    "shoulder_front": {"kp": 124.0, "kd": 4.8},
    "shoulder_side": {"kp": 60.0, "kd": 5.0},
    "elbow": {"kp": 65.0, "kd": 1.5},
    "arm_roll": {"kp": 18.0, "kd": 1.0},
    "wrist_side": {"kp": 16.0, "kd": 2.2},
    "wrist": {"kp": 22.0, "kd": 1.4},
}

COUPLED_CLEARANCE_MAX_SECONDS = 12.0
COUPLED_CLEARANCE_SETTLE_SECONDS = 0.5
COUPLED_CLEARANCE_CONTROL_DT = 0.01
COUPLED_CLEARANCE_TRAJECTORY = "blend_smootherstep"
COUPLED_CLEARANCE_LINEAR_BLEND = 0.35
COUPLED_CLEARANCE_PROGRESS_WINDOWS = {
    "arm_roll": (0.35, 1.0),
    "wrist": (0.0, 1.0),
}

COUPLED_CLEARANCE_PRE_WINDOW_GAINS = {
    "wrist": {"kp": 6.0, "kd": 0.8},
}

COUPLED_CLEARANCE_VELOCITY_FF_JOINTS = {
    "shoulder_front",
}

COUPLED_CLEARANCE_MOVE_TAU_FF = {
    "shoulder_front": 1.0,
}

CLEARANCE_HOLD_GAINS = {
    "wrist": {"kp": 18.0, "kd": 1.4},
    "wrist_side": {"kp": 18.0, "kd": 1.4},
    "arm_roll": {"kp": 26.0, "kd": 5.0},
    "elbow": {"kp": 92.0, "kd": 1.2},
    "shoulder_front": {"kp": 125.0, "kd": 1.5},
    "shoulder_side": {"kp": 70.0, "kd": 5.0},
    "shoulder_rotate": {"kp": 45.0, "kd": 4.5},
}

CLEARANCE_COMPLIANT_HOLD_GAINS = {
    "arm_roll": {"kp": 6.0, "kd": 1.0},
    "wrist_side": {"kp": 8.0, "kd": 1.6},
    "shoulder_rotate": {"kp": 8.0, "kd": 4.0},
}

CLEARANCE_COMPLIANT_HOLDS_BY_ACTIVE = {
    "wrist_side": {"arm_roll"},
    "wrist": {"arm_roll", "wrist_side", "shoulder_rotate"},
}

CLEARANCE_JOINT_HOLD_TAU = {
    "shoulder_front": 3.0,
}

NUDGE_HOLD_TAU = {
    **CLEARANCE_JOINT_HOLD_TAU,
    "shoulder_front": 3.8,
    "elbow": 2.2,
    "wrist": 0.55,
}

NUDGE_WRIST_ACTIVE_LOW_SHOULDER_FRONT_THRESHOLD = 1.8
LOW_SHOULDER_POSTURE = "low_shoulder"
HOLD_TAU_RULES = {
    "base": {
        "shoulder_front": 3.8,
        "elbow": 2.2,
        "wrist": 0.55,
    },
    LOW_SHOULDER_POSTURE: {
        "*": {
            "shoulder_front": 1.2,
        },
        "shoulder_front": {
            "arm_roll": -0.55,
            "shoulder_rotate": -0.8,
            "shoulder_side": 0.7,
            "wrist_side": -0.35,
        },
        "arm_roll": {
            "elbow": 5.1,
            "shoulder_rotate": -0.8,
            "wrist_side": -0.25,
        },
        "wrist_side": {
            "arm_roll": -0.55,
            "shoulder_rotate": -0.8,
            "shoulder_side": 0.7,
        },
        "wrist": {
            "arm_roll": -0.55,
            "shoulder_rotate": -0.8,
            "shoulder_side": 0.7,
            "wrist_side": -0.35,
        },
    },
}
HOLD_TAU_LIMITS = {
    "shoulder_front": (0.8, 3.8),
    "shoulder_side": (0.0, 1.0),
    "shoulder_rotate": (-1.0, 0.0),
    "elbow": (1.0, 5.4),
    "arm_roll": (-0.8, -0.2),
    "wrist_side": (-0.45, 0.0),
    "wrist": (0.35, 0.7),
}
ADAPTIVE_HOLD_TAU_ERROR_DEADBAND_DEG = 1.5
ADAPTIVE_HOLD_TAU_IMPROVEMENT_DEADBAND_DEG = 0.15
ADAPTIVE_HOLD_TAU_STEP_PER_DEG = 0.01
ADAPTIVE_HOLD_TAU_MAX_STEP = 0.08
ADAPTIVE_HOLD_TAU_MIN_EXPLORATION_STEP = 0.01
ADAPTIVE_HOLD_TAU_MIN_STEP_SCALE = 0.20
ADAPTIVE_HOLD_TAU_TARGET_BIAS_HANDOFF_DEG = 1.1
ADAPTIVE_TARGET_BIAS_ERROR_DEADBAND_DEG = 1.0
ADAPTIVE_TARGET_BIAS_STEP_SCALE = 0.5
ADAPTIVE_TARGET_BIAS_MAX_STEP_DEG = 0.75
ADAPTIVE_TARGET_BIAS_LIMIT_DEG = 5.0
ADAPTIVE_TARGET_BIAS_MIN_HOLD_TAU_SAMPLES = 3
ADAPTIVE_HOLD_TARGET_BIAS_STEP_SCALE = 0.5
ADAPTIVE_HOLD_TARGET_BIAS_MAX_STEP_DEG = 0.75
ADAPTIVE_HOLD_TARGET_BIAS_LIMIT_DEG = 5.0
ADAPTIVE_ACTIVE_TAU_ERROR_DEADBAND_DEG = 1.0
ADAPTIVE_ACTIVE_TAU_IMPROVEMENT_DEADBAND_DEG = 0.20
ADAPTIVE_ACTIVE_TAU_STEP_PER_DEG = 0.02
ADAPTIVE_ACTIVE_TAU_MAX_STEP = 0.05
ADAPTIVE_ACTIVE_TAU_MIN_STEP_SCALE = 0.20
ACTIVE_TAU_RULES = {
    "base": {
        "shoulder_front": {"positive": 2.4, "negative": 0.0},
        "wrist": {"positive": 0.40, "negative": 0.40},
    },
    LOW_SHOULDER_POSTURE: {
        "arm_roll": {"positive": -0.45, "negative": -0.65},
    },
}
ACTIVE_TAU_LIMITS = {
    "shoulder_front": (0.0, 2.4),
    "arm_roll": (-0.8, 0.2),
    "wrist": (0.35, 0.7),
}

NUDGE_LOW_SHOULDER_FRONT_HOLD_TAU = HOLD_TAU_RULES[LOW_SHOULDER_POSTURE]["*"]["shoulder_front"]
NUDGE_LOW_SHOULDER_WRIST_SIDE_HOLD_TAU = HOLD_TAU_RULES[LOW_SHOULDER_POSTURE]["wrist"]["wrist_side"]
NUDGE_LOW_SHOULDER_GAINS = {
    "wrist_side": {"kp": 24.0, "kd": 2.4},
}
NUDGE_LOW_SHOULDER_MIN_SECONDS = {
    "wrist_side": 4.5,
}
NUDGE_LOW_SHOULDER_WRIST_SIDE_FINE_DEADBAND_DEG = 0.8
NUDGE_LOW_SHOULDER_WRIST_SIDE_FINE_MAX_BIAS_DEG = 1.2
NUDGE_LOW_SHOULDER_WRIST_SIDE_FINE_GAINS = {
    "kp": 24.0,
    "kd": 2.8,
    "seconds": 2.0,
}
NUDGE_LOW_SHOULDER_WRIST_HOLD_GAINS = {
    "shoulder_rotate": {"kp": 24.0, "kd": 4.5},
    "shoulder_side": {"kp": 65.0, "kd": 4.5},
    "arm_roll": {"kp": 12.0, "kd": 2.0},
}
NUDGE_LOW_SHOULDER_WRIST_HOLD_TAU = {
    "arm_roll": HOLD_TAU_RULES[LOW_SHOULDER_POSTURE]["wrist"]["arm_roll"],
    "shoulder_rotate": HOLD_TAU_RULES[LOW_SHOULDER_POSTURE]["wrist"]["shoulder_rotate"],
    "shoulder_side": HOLD_TAU_RULES[LOW_SHOULDER_POSTURE]["wrist"]["shoulder_side"],
}
NUDGE_LOW_SHOULDER_ARM_ROLL_ACTIVE_TAU = ACTIVE_TAU_RULES[LOW_SHOULDER_POSTURE]["arm_roll"]["negative"]
NUDGE_LOW_SHOULDER_ARM_ROLL_HOLD_TAU = {
    "elbow": HOLD_TAU_RULES[LOW_SHOULDER_POSTURE]["arm_roll"]["elbow"],
    "shoulder_rotate": HOLD_TAU_RULES[LOW_SHOULDER_POSTURE]["arm_roll"]["shoulder_rotate"],
    "wrist_side": HOLD_TAU_RULES[LOW_SHOULDER_POSTURE]["arm_roll"]["wrist_side"],
}

NUDGE_ACTIVE_TAU = {
    "shoulder_front": 2.4,
    "wrist": 0.55,
}

NUDGE_PRELOAD_SECONDS = {
    "shoulder_front": 0.8,
}

NUDGE_TRAJECTORY = {
    "shoulder_front": "blend_smootherstep",
}

NUDGE_LINEAR_BLEND = {
    "shoulder_front": 0.35,
}

NUDGE_STEP_DEG = {}


NUDGE_MIN_SECONDS = {
    "shoulder_front": 2.2,
    "arm_roll": 1.2,
}

PREHOME_CLEARANCE_GAINS = {
    "wrist_side": {"kp": 16.0, "kd": 2.2},
    "arm_roll": {"kp": 12.0, "kd": 2.0},
}

PREHOME_CLEARANCE_BASE_SECONDS = {
    "wrist_side": 6.0,
    "arm_roll": 8.0,
}

PREHOME_CLEARANCE_SECONDS_PER_DEG = {
    "wrist_side": 6.0 / 5.0,
    "arm_roll": 8.0 / 10.0,
}

PREHOME_CLEARANCE_MAX_SECONDS = {
    "wrist_side": 20.0,
    "arm_roll": 20.0,
}

NUDGE_COMPLIANT_HOLD_GAINS = {
    "arm_roll": {"kp": 4.0, "kd": 1.0},
    "shoulder_rotate": {"kp": 6.0, "kd": 5.0},
    "wrist_side": {"kp": 6.0, "kd": 1.2},
    "wrist": {"kp": 8.0, "kd": 1.4},
}

NUDGE_COMPLIANT_HOLD_GAINS_BY_ACTIVE = {
    "shoulder_front": {
        "arm_roll": {"kp": 2.5, "kd": 2.0},
        "shoulder_rotate": {"kp": 4.0, "kd": 1.0},
        "wrist_side": {"kp": 4.0, "kd": 1.6},
        "wrist": {"kp": 6.0, "kd": 2.0},
    },
    "shoulder_side": {
        "arm_roll": {"kp": 2.5, "kd": 2.0},
        "shoulder_rotate": {"kp": 4.0, "kd": 1.0},
        "wrist_side": {"kp": 4.0, "kd": 1.6},
        "wrist": {"kp": 6.0, "kd": 2.0},
    },
    "elbow": {
        "arm_roll": {"kp": 2.5, "kd": 2.0},
        "shoulder_rotate": {"kp": 4.0, "kd": 1.0},
        "wrist_side": {"kp": 4.0, "kd": 1.6},
        "wrist": {"kp": 6.0, "kd": 2.0},
    },
    "arm_roll": {
        "shoulder_rotate": {"kp": 4.0, "kd": 1.0},
        "wrist_side": {"kp": 4.0, "kd": 1.6},
        "wrist": {"kp": 6.0, "kd": 2.0},
    },
    "wrist": {
        "arm_roll": {"kp": 8.0, "kd": 1.0},
    },
}

NUDGE_COMPLIANT_HOLDS_BY_ACTIVE = {
    "shoulder_front": {"arm_roll", "shoulder_rotate", "wrist_side", "wrist"},
    "shoulder_side": {"arm_roll", "shoulder_rotate", "wrist_side", "wrist"},
    "elbow": {"arm_roll", "shoulder_rotate", "wrist_side", "wrist"},
    "arm_roll": {"shoulder_rotate", "wrist_side", "wrist"},
    "shoulder_rotate": {"arm_roll", "wrist_side", "wrist"},
    "wrist": {"arm_roll"},
}

POSTURE_HOLD_GAIN_RULES = {
    LOW_SHOULDER_POSTURE: {
        "*": {
            "arm_roll": {"kp": 12.0, "kd": 2.0},
            "shoulder_rotate": {"kp": 12.0, "kd": 5.0},
            "wrist_side": {"kp": 8.0, "kd": 1.6},
        },
        "shoulder_front": {
            "wrist": {"kp": 6.0, "kd": 2.0},
        },
        "arm_roll": {
            "wrist": {"kp": 6.0, "kd": 2.0},
        },
        "wrist": {
            **NUDGE_LOW_SHOULDER_WRIST_HOLD_GAINS,
            "wrist_side": {"kp": 24.0, "kd": 2.4},
        },
    },
}

NUDGE_LOW_SHOULDER_COMPLIANT_HOLD_GAINS_BY_ACTIVE = {
    active: {
        **POSTURE_HOLD_GAIN_RULES[LOW_SHOULDER_POSTURE].get("*", {}),
        **overrides,
    }
    for active, overrides in POSTURE_HOLD_GAIN_RULES[LOW_SHOULDER_POSTURE].items()
    if active != "*"
}

NUDGE_LOW_SHOULDER_COMPLIANT_HOLD_GAINS_BY_ACTIVE.setdefault(
    "shoulder_front",
    {
        "arm_roll": {"kp": 12.0, "kd": 2.0},
        "shoulder_rotate": {"kp": 12.0, "kd": 5.0},
        "wrist_side": {"kp": 8.0, "kd": 1.6},
    },
)
NUDGE_LOW_SHOULDER_COMPLIANT_HOLD_GAINS_BY_ACTIVE.setdefault(
    "arm_roll",
    {
        "shoulder_rotate": {"kp": 12.0, "kd": 5.0},
        "wrist_side": {"kp": 8.0, "kd": 1.6},
        "wrist": {"kp": 6.0, "kd": 2.0},
    },
)

NUDGE_COUPLED_ACTIVE_RATIOS = {}

NUDGE_COUPLED_ACTIVE_GAINS = {}

NUDGE_TARGET_LIMITS = {}


CLEARANCE_WRIST_FINE_DEADBAND_DEG = 1.0
CLEARANCE_WRIST_FINE_MAX_BIAS_DEG = 1.5
CLEARANCE_WRIST_FINE_SETTLE_SECONDS = 1.0
CLEARANCE_WRIST_FINE_ACTIVE_TAU = 0.55
CLEARANCE_WRIST_FINE_CONTROL_DT = 0.01
CLEARANCE_WRIST_FINE_GAINS = {
    "kp": 28.0,
    "kd": 5.0,
    "seconds": 4.0,
}
COUPLED_CLEARANCE_WRIST_FINE_GAINS = {
    "kp": 26.0,
    "kd": 4.7,
    "seconds": 8.0,
}

WRIST_ACTIVE_SOFT_GAINS = {
    "kp": COUPLED_CLEARANCE_MOVE_GAINS["wrist"]["kp"],
    "kd": COUPLED_CLEARANCE_MOVE_GAINS["wrist"]["kd"],
    "seconds": 12.0,
    "max_seconds": 12.0,
}
WRIST_ACTIVE_REPLAY_TRAJECTORY = "blend_smootherstep"
WRIST_ACTIVE_REPLAY_LINEAR_BLEND = 0.35
WRIST_ACTIVE_REPLAY_VELOCITY_FF = False
WRIST_ACTIVE_REPLAY_ACTIVE_TAU = 0.0
WRIST_ACTIVE_NUDGE_GAINS = {
    "kp": 22.0,
    "kd": 4.7,
}
WRIST_ACTIVE_NUDGE_MIN_SECONDS = 6.0

CLEARANCE_BASE_HOLD_GAINS = {
    "wrist": {"kp": 6.0, "kd": 0.8},
    "wrist_side": {"kp": 6.0, "kd": 0.8},
    "arm_roll": {"kp": 12.0, "kd": 2.0},
    "elbow": {"kp": 25.0, "kd": 3.0},
    "shoulder_front": {"kp": 30.0, "kd": 4.0},
    "shoulder_side": {"kp": 18.0, "kd": 2.5},
    "shoulder_rotate": {"kp": 12.0, "kd": 2.5},
}

NUDGE_GAINS = {
    "wrist": {"kp": WRIST_ACTIVE_SOFT_GAINS["kp"], "kd": WRIST_ACTIVE_SOFT_GAINS["kd"]},
    "wrist_side": {"kp": 18.0, "kd": 1.2},
    "arm_roll": {"kp": 12.0, "kd": 2.0},
    "elbow": {"kp": 70.0, "kd": 3.0},
    "shoulder_front": {"kp": 140.0, "kd": 0.2},
    "shoulder_side": {"kp": 70.0, "kd": 3.0},
    "shoulder_rotate": {"kp": 60.0, "kd": 3.0},
}

CLAW_OPEN_TOL = 0.08
CLAW_CLOSE_OFFSET = 6.0
CLAW_MOVE_SECONDS = 4.0
CLAW_CLOSE_SECONDS = 8.0
CLAW_KP_MOVE = 28.0
CLAW_KD_MOVE = 1.0
CLAW_KP_OPEN = 22.0
CLAW_KD_OPEN = 0.8
CLAW_KP_HOLD = 14.0
CLAW_KD_HOLD = 0.7
CLAW_TAU_THRESHOLD = 0.30
CLAW_STALL_TAU_THRESHOLD = 0.24
CLAW_VEL_STALL_THRESHOLD = 0.08
CLAW_CONFIRM_COUNT_NEEDED = 5
CLAW_BACKOFF = 0.04
CLAW_HOLD_TRACE_INTERVAL = 1.0


def smoothstep(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return t * t * (3.0 - 2.0 * t)


def smootherstep(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0)


def smootherstep_derivative(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return 30.0 * t * t * (1.0 - t) * (1.0 - t)


def blend_smootherstep(t: float, linear_blend: float = 0.15) -> float:
    t = max(0.0, min(1.0, t))
    linear_blend = max(0.0, min(1.0, linear_blend))
    return linear_blend * t + (1.0 - linear_blend) * smootherstep(t)


def blend_smootherstep_derivative(t: float, linear_blend: float = 0.15) -> float:
    t = max(0.0, min(1.0, t))
    linear_blend = max(0.0, min(1.0, linear_blend))
    return linear_blend + (1.0 - linear_blend) * smootherstep_derivative(t)


def cosine_smoothstep(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return 0.5 - 0.5 * math.cos(math.pi * t)


def parse_joints(value: str) -> List[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def ensure_parent(path: str) -> None:
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)


class LeftArmV2:
    def __init__(self, port: str = SERIAL_PORT, baud: int = SERIAL_BAUD) -> None:
        self.motion_dynamics_model = configured_model()
        self.serial = serial.Serial(port, baud, timeout=1.0)
        self.ctrl = MotorControl(self.serial)
        self.specs = {spec.name: spec for spec in ALL_MOTOR_SPECS}
        self.motors: Dict[str, Motor] = {}
        self.enabled: set[str] = set()
        for spec in ALL_MOTOR_SPECS:
            motor = Motor(spec.motor_type, spec.slave_id, spec.master_id)
            self.ctrl.addMotor(motor)
            self.motors[spec.name] = motor

    def close(self) -> None:
        self.serial.close()
        config = (getattr(self, 'motion_dynamics_model', None) or {}).get('rigid_body_configuration')
        if config is not None:
            from left_arm_general_motion import close_runtime_configuration
            close_runtime_configuration(config)

    def validate(self, names: Iterable[str]) -> List[str]:
        names = list(names)
        unknown = sorted(set(names) - set(self.specs))
        if unknown:
            raise ValueError("unknown joints: " + ", ".join(unknown))
        return names

    def enable(self, names: Iterable[str]) -> None:
        for name in self.validate(names):
            if name in self.enabled:
                print("enable skip", name)
                continue
            print("enable", name)
            self.ctrl.enable(self.motors[name])
            self.enabled.add(name)
            time.sleep(0.05)

    def disable(self, names: Iterable[str]) -> None:
        disable_fn = (
            getattr(self.ctrl, "disable", None)
            or getattr(self.ctrl, "disableMotor", None)
            or getattr(self.ctrl, "disable_motor", None)
        )
        if disable_fn is None:
            raise RuntimeError("MotorControl does not expose disable/disableMotor/disable_motor; cannot restart motors safely.")
        for name in self.validate(names):
            print("disable", name)
            disable_fn(self.motors[name])
            self.enabled.discard(name)
            time.sleep(0.05)

    def restart_motors(
        self,
        names: Iterable[str],
        off_seconds: float,
        hold_seconds: float,
        hold_kp: float,
        hold_kd: float,
    ) -> None:
        names = self.validate(names)
        print("v2.6 restart before:")
        self.print_status(names)
        self.disable(names)
        time.sleep(off_seconds)
        self.enable(names)
        time.sleep(0.1)
        if hold_seconds > 0:
            targets = self.positions(names)
            print("v2.6 restart hold current positions seconds=", hold_seconds, "kp=", hold_kp, "kd=", hold_kd)
            self.hold_positions(targets, seconds=hold_seconds, kp=hold_kp, kd=hold_kd)
        print("v2.6 restart after:")
        self.print_status(names)

    def read_status(self, names: Iterable[str]) -> Dict[str, Dict[str, float]]:
        names = self.validate(names)
        for name in names:
            self.ctrl.refresh_motor_status(self.motors[name])
        time.sleep(0.02)
        self.ctrl.recv()
        return {
            name: {
                "pos": float(self.motors[name].getPosition()),
                "vel": float(self.motors[name].getVelocity()),
                "tau": float(self.motors[name].getTorque()),
            }
            for name in names
        }

    def positions(self, names: Iterable[str]) -> Dict[str, float]:
        return {name: data["pos"] for name, data in self.read_status(names).items()}

    def print_status(self, names: Iterable[str]) -> None:
        print(json.dumps(self.read_status(names), ensure_ascii=False, indent=2))

    def hold_positions(
        self,
        targets: Dict[str, float],
        seconds: float,
        kp: float,
        kd: float,
    ) -> None:
        names = self.validate(targets.keys())
        end = time.time() + seconds
        while time.time() < end:
            for name in names:
                self.ctrl.controlMIT(self.motors[name], kp, kd, targets[name], 0, 0)
            time.sleep(0.02)

    def hold_positions_with_gains(
        self,
        targets: Dict[str, float],
        seconds: float,
        gains: Dict[str, Dict[str, float]],
        fallback_kp: float,
        fallback_kd: float,
        hold_tau: Optional[Dict[str, float]] = None,
    ) -> None:
        names = self.validate(targets.keys())
        hold_tau = hold_tau or {}
        end = time.time() + seconds
        while time.time() < end:
            for name in names:
                joint_gains = gains.get(name, {})
                kp = joint_gains.get("kp", fallback_kp)
                kd = joint_gains.get("kd", fallback_kd)
                self.ctrl.controlMIT(self.motors[name], kp, kd, targets[name], 0, hold_tau.get(name, 0.0))
            time.sleep(0.02)

    def hold_current(
        self,
        names: Iterable[str],
        seconds: float,
        kp: float,
        kd: float,
    ) -> None:
        targets = self.positions(names)
        self.hold_positions(targets, seconds=seconds, kp=kp, kd=kd)

    def claw_status(self) -> Dict[str, float]:
        return self.read_status(["claw"])["claw"]

    def claw_hold(self, target: float, seconds: float, kp: float = CLAW_KP_HOLD, kd: float = CLAW_KD_HOLD) -> None:
        start = time.time()
        while time.time() - start < seconds:
            self.ctrl.controlMIT(self.motors["claw"], kp, kd, target, 0, 0)
            time.sleep(0.01)

    def claw_hold_forever(self, target: float, kp: float = CLAW_KP_HOLD, kd: float = CLAW_KD_HOLD) -> None:
        print("claw holding at:", target, "Ctrl+C to stop", flush=True)
        next_trace = time.time()
        while True:
            self.ctrl.controlMIT(self.motors["claw"], kp, kd, target, 0, 0)
            now = time.time()
            if now >= next_trace:
                status = self.claw_status()
                print(
                    "claw holding status=",
                    json.dumps({"target": target, "kp": kp, "kd": kd, **status}, ensure_ascii=False),
                    flush=True,
                )
                next_trace = now + CLAW_HOLD_TRACE_INTERVAL
            time.sleep(0.01)

    def claw_move_to(
        self,
        target: float,
        seconds: float,
        kp: float = CLAW_KP_MOVE,
        kd: float = CLAW_KD_MOVE,
        label: str = "claw move",
    ) -> Dict[str, float]:
        start_pos = self.claw_status()["pos"]
        print(label, "from:", start_pos, "to:", target, "kp=", kp, "kd=", kd, "seconds=", seconds)
        start = time.time()
        while time.time() - start < seconds:
            a = (time.time() - start) / max(seconds, 1e-6)
            s = cosine_smoothstep(a)
            pos_target = start_pos * (1.0 - s) + target * s
            self.ctrl.controlMIT(self.motors["claw"], kp, kd, pos_target, 0, 0)
            time.sleep(0.01)
        self.claw_hold(target, 0.8)
        status = self.claw_status()
        print(label, "target:", target, "pos:", status["pos"], "vel:", status["vel"], "tau:", status["tau"])
        return status

    def claw_home(self, home_pos: float) -> Dict[str, float]:
        self.enable(["claw"])
        return self.claw_move_to(home_pos, CLAW_MOVE_SECONDS, kp=CLAW_KP_OPEN, kd=CLAW_KD_OPEN, label="claw home")

    def claw_close_until_pressure(
        self,
        home_pos: float,
        hold: bool = True,
        close_offset: float = CLAW_CLOSE_OFFSET,
    ) -> Dict[str, object]:
        self.enable(["claw"])
        q_close = home_pos + close_offset
        print("claw close pressure stop")
        print("claw home:", home_pos)
        print("claw close target:", q_close)
        contact = False
        contact_pos = home_pos
        confirm_count = 0
        last_status = self.claw_status()
        start = time.time()
        while time.time() - start < CLAW_CLOSE_SECONDS:
            elapsed = time.time() - start
            a = elapsed / max(CLAW_CLOSE_SECONDS, 1e-6)
            s = cosine_smoothstep(a)
            target = home_pos * (1.0 - s) + q_close * s
            self.ctrl.controlMIT(self.motors["claw"], CLAW_KP_MOVE, CLAW_KD_MOVE, target, 0, 0)
            time.sleep(0.01)
            last_status = self.claw_status()
            pos = last_status["pos"]
            vel = last_status["vel"]
            tau = last_status["tau"]
            if elapsed > 0.5:
                tau_hit = tau > CLAW_TAU_THRESHOLD
                stall_hit = (
                    abs(vel) < CLAW_VEL_STALL_THRESHOLD
                    and abs(target - pos) > 0.15
                    and tau > CLAW_STALL_TAU_THRESHOLD
                )
                if tau_hit or stall_hit:
                    confirm_count += 1
                else:
                    confirm_count = 0
                if confirm_count >= CLAW_CONFIRM_COUNT_NEEDED:
                    contact = True
                    contact_pos = pos
                    print("CLAW CONTACT detected")
                    print("pos:", pos, "vel:", vel, "tau:", tau, "target:", target)
                    break
            if int(elapsed * 10) % 20 == 0:
                print("claw closing pos:", pos, "vel:", vel, "tau:", tau, "target:", target)
        if contact:
            hold_pos = contact_pos - CLAW_BACKOFF
            result = {"contact": True, "contact_pos": contact_pos, "hold_pos": hold_pos, "status": last_status}
        else:
            hold_pos = last_status["pos"]
            result = {"contact": False, "contact_pos": None, "hold_pos": hold_pos, "status": last_status}
            print("claw no contact detected")
            print("final close pos:", last_status["pos"], "vel:", last_status["vel"], "tau:", last_status["tau"])
        print("claw pressure result:", json.dumps(result, ensure_ascii=False, indent=2))
        if hold:
            self.claw_hold_forever(float(hold_pos))
        else:
            self.claw_hold(float(hold_pos), 1.0)
        return result

    def move_targets(
        self,
        targets: Dict[str, float],
        seconds: float,
        kp: float,
        kd: float,
    ) -> None:
        names = self.validate(targets.keys())
        starts = self.positions(names)
        dynamics = begin_motion(self, names)
        self.hold_positions(starts, seconds=0.2, kp=kp, kd=kd)
        start_time = time.time()
        while time.time() - start_time < seconds:
            t = (time.time() - start_time) / max(seconds, 1e-6)
            s = smoothstep(t)
            ds, dds = reference_derivatives('smoothstep', t, max(seconds, 1e-6))
            prepare_frame(dynamics, {name: starts[name] * (1.0 - s) + targets[name] * s
                                     for name in names}, t,
                          {name: (targets[name]-starts[name])*ds for name in names},
                          {name: (targets[name]-starts[name])*dds for name in names})
            for name in names:
                target = starts[name] * (1.0 - s) + targets[name] * s
                send_command(self, dynamics, name, kp, kd, target, 0, 0)
            time.sleep(0.02)
        start_time = time.time()
        while time.time() - start_time < 0.5:
            prepare_frame(dynamics, targets, 1.0, dict.fromkeys(names, 0.0), dict.fromkeys(names, 0.0))
            for name in names:
                send_command(self, dynamics, name, kp, kd, targets[name], 0, 0)
            time.sleep(0.02)
        finish_motion(dynamics)

    def move_targets_auto_gains(
        self,
        targets: Dict[str, float],
        seconds: float,
        gains: Dict[str, Dict[str, float]],
        fallback_kp: float,
        fallback_kd: float,
    ) -> None:
        names = self.validate(targets.keys())
        starts = self.positions(names)
        dynamics = begin_motion(self, names)
        start_time = time.time()
        while time.time() - start_time < 0.2:
            for name in names:
                joint_gains = gains.get(name, {})
                kp = joint_gains.get("kp", fallback_kp)
                kd = joint_gains.get("kd", fallback_kd)
                self.ctrl.controlMIT(self.motors[name], kp, kd, starts[name], 0, 0)
            time.sleep(0.02)

        start_time = time.time()
        while time.time() - start_time < seconds:
            t = (time.time() - start_time) / max(seconds, 1e-6)
            s = smoothstep(t)
            ds, dds = reference_derivatives('smoothstep', t, max(seconds, 1e-6))
            prepare_frame(dynamics, {name: starts[name] * (1.0 - s) + targets[name] * s
                                     for name in names}, t,
                          {name: (targets[name]-starts[name])*ds for name in names},
                          {name: (targets[name]-starts[name])*dds for name in names})
            for name in names:
                joint_gains = gains.get(name, {})
                kp = joint_gains.get("kp", fallback_kp)
                kd = joint_gains.get("kd", fallback_kd)
                target = starts[name] * (1.0 - s) + targets[name] * s
                send_command(self, dynamics, name, kp, kd, target, 0, 0)
            time.sleep(0.02)

        start_time = time.time()
        while time.time() - start_time < 0.5:
            prepare_frame(dynamics, targets, 1.0, dict.fromkeys(names, 0.0), dict.fromkeys(names, 0.0))
            for name in names:
                joint_gains = gains.get(name, {})
                kp = joint_gains.get("kp", fallback_kp)
                kd = joint_gains.get("kd", fallback_kd)
                send_command(self, dynamics, name, kp, kd, targets[name], 0, 0)
            time.sleep(0.02)
        finish_motion(dynamics)

    def move_target_with_holds(
        self,
        name: str,
        target: float,
        seconds_per_step: float,
        kp: float,
        kd: float,
        hold_targets: Dict[str, float],
        hold_gains: Dict[str, Dict[str, float]],
        fallback_kp: float,
        fallback_kd: float,
        hold_tau: Optional[Dict[str, float]] = None,
        active_velocity_ff: bool = False,
        active_tau: float = 0.0,
        step_deg: float = 0.0,
        control_dt: float = 0.02,
        preload_seconds: float = 0.2,
        trajectory: str = "smoothstep",
        linear_blend: float = 0.0,
        trace_names: Optional[List[str]] = None,
        trace_interval: float = 0.5,
        max_velocity: Optional[float] = None,
        max_position_error_deg: Optional[float] = None,
        active_max_delta_deg: Optional[float] = None,
    ) -> None:
        self.validate([name] + list(hold_targets.keys()))
        start = self.positions([name])[name]
        dynamics = begin_motion(self, [name] + list(hold_targets))
        delta = target - start
        if step_deg > 0:
            steps = int(math.ceil(abs(math.degrees(delta)) / step_deg))
        else:
            steps = 1
        steps = max(1, steps)

        hold_tau = hold_tau or {}
        trace_names = trace_names or []
        all_targets = dict(hold_targets)
        all_targets[name] = start
        safety_names = [name] + list(hold_targets.keys())
        safety_reference = dict(hold_targets)
        safety_reference[name] = start
        safety_counter = 0

        def check_safety() -> None:
            nonlocal safety_counter
            if max_velocity is None and max_position_error_deg is None:
                return
            safety_counter += 1
            if safety_counter % 8:
                return
            status = self.read_status(safety_names)
            for safety_name, row in status.items():
                velocity = abs(float(row["vel"]))
                if max_velocity is not None and velocity > max_velocity:
                    raise RuntimeError(
                        f"nudge watchdog tripped for {safety_name}: "
                        f"velocity {velocity:.3f}rad/s"
                    )
                if max_position_error_deg is None:
                    continue
                displacement_deg = abs(
                    math.degrees(float(row["pos"]) - safety_reference[safety_name])
                )
                limit_deg = max_position_error_deg
                if safety_name == name and active_max_delta_deg is not None:
                    limit_deg += active_max_delta_deg
                if displacement_deg > limit_deg:
                    raise RuntimeError(
                        f"nudge watchdog tripped for {safety_name}: "
                        f"position displacement {displacement_deg:.2f}deg"
                    )
        start_time = time.time()
        while time.time() - start_time < preload_seconds:
            for hold_name, hold_target in all_targets.items():
                if hold_name == name:
                    joint_kp = kp
                    joint_kd = kd
                    joint_tau = active_tau
                else:
                    joint_gains = hold_gains.get(hold_name, {})
                    joint_kp = joint_gains.get("kp", fallback_kp)
                    joint_kd = joint_gains.get("kd", fallback_kd)
                    joint_tau = hold_tau.get(hold_name, 0.0)
                self.ctrl.controlMIT(self.motors[hold_name], joint_kp, joint_kd, hold_target, 0, joint_tau)
            check_safety()
            time.sleep(control_dt)

        previous = start
        for step in range(1, steps + 1):
            intermediate = start + delta * (step / steps)
            print("v2 continuous step", name, f"{step}/{steps}", "target=", intermediate)
            step_start = time.time()
            next_trace_time = step_start
            while time.time() - step_start < seconds_per_step:
                now = time.time()
                t = (now - step_start) / max(seconds_per_step, 1e-6)
                if active_velocity_ff and steps == 1:
                    if trajectory == "blend_smootherstep":
                        s = blend_smootherstep(t, linear_blend)
                        active_velocity = delta * blend_smootherstep_derivative(t, linear_blend) / max(seconds_per_step, 1e-6)
                    else:
                        s = smootherstep(t)
                        active_velocity = delta * smootherstep_derivative(t) / max(seconds_per_step, 1e-6)
                elif trajectory == "blend_smootherstep":
                    s = blend_smootherstep(t, linear_blend)
                    active_velocity = 0.0
                else:
                    s = smoothstep(t)
                    active_velocity = 0.0
                active_target = previous * (1.0 - s) + intermediate * s
                frame_targets = dict(hold_targets)
                frame_targets[name] = active_target
                reference_kind = ('blend_smootherstep' if trajectory == 'blend_smootherstep'
                                  else 'smootherstep' if active_velocity_ff and steps == 1 else 'smoothstep')
                ds, dds = reference_derivatives(reference_kind, t, max(seconds_per_step, 1e-6), linear_blend)
                reference_velocities = dict.fromkeys(frame_targets, 0.0)
                reference_accelerations = dict.fromkeys(frame_targets, 0.0)
                reference_velocities[name] = (intermediate-previous)*ds
                reference_accelerations[name] = (intermediate-previous)*dds
                prepare_frame(dynamics, frame_targets, (step - 1 + t) / steps,
                              reference_velocities, reference_accelerations)
                send_command(self, dynamics, name, kp, kd, active_target, active_velocity, active_tau)
                for hold_name, hold_target in hold_targets.items():
                    joint_gains = hold_gains.get(hold_name, {})
                    joint_kp = joint_gains.get("kp", fallback_kp)
                    joint_kd = joint_gains.get("kd", fallback_kd)
                    send_command(
                        self, dynamics, hold_name,
                        joint_kp,
                        joint_kd,
                        hold_target,
                        0,
                        hold_tau.get(hold_name, 0.0),
                    )
                if trace_names and now >= next_trace_time:
                    print(
                        "v2 continuous trace",
                        name,
                        f"{step}/{steps}",
                        "t=",
                        round(now - step_start, 3),
                        json.dumps(self.read_status(trace_names), ensure_ascii=False),
                    )
                    next_trace_time = now + trace_interval
                check_safety()
                time.sleep(control_dt)
            previous = intermediate

        final_targets = dict(hold_targets)
        final_targets[name] = target
        start_time = time.time()
        while time.time() - start_time < 0.5:
            prepare_frame(dynamics, final_targets, 1.0, dict.fromkeys(final_targets, 0.0), dict.fromkeys(final_targets, 0.0))
            for hold_name, hold_target in final_targets.items():
                if hold_name == name:
                    joint_kp = kp
                    joint_kd = kd
                    joint_tau = active_tau
                else:
                    joint_gains = hold_gains.get(hold_name, {})
                    joint_kp = joint_gains.get("kp", fallback_kp)
                    joint_kd = joint_gains.get("kd", fallback_kd)
                    joint_tau = hold_tau.get(hold_name, 0.0)
                send_command(self, dynamics, hold_name, joint_kp, joint_kd, hold_target, 0, joint_tau)
            check_safety()
            time.sleep(control_dt)
        finish_motion(dynamics)

    def move_targets_with_holds(
        self,
        targets: Dict[str, float],
        seconds_per_step: float,
        move_gains: Dict[str, Dict[str, float]],
        hold_targets: Dict[str, float],
        hold_gains: Dict[str, Dict[str, float]],
        fallback_kp: float,
        fallback_kd: float,
        hold_tau: Optional[Dict[str, float]] = None,
        step_deg: float = 0.0,
        preload_seconds: float = 0.2,
        progress_windows: Optional[Dict[str, Tuple[float, float]]] = None,
        pre_window_gains: Optional[Dict[str, Dict[str, float]]] = None,
        control_dt: float = 0.02,
        velocity_ff_joints: Optional[Set[str]] = None,
        move_tau_ff: Optional[Dict[str, float]] = None,
        trajectory: str = "smoothstep",
        linear_blend: float = 0.0,
        watchdog=None,
        move_tau_ff_initializer=None,
        move_reference_starts=None,
        move_boundary_keepalive=None,
    ) -> None:
        active_names = self.validate(targets.keys())
        self.validate(list(hold_targets.keys()))
        if move_boundary_keepalive is not None:move_boundary_keepalive()
        starts = self.positions(active_names)
        if move_boundary_keepalive is not None:move_boundary_keepalive()
        # Resolve continuation torque at the actual interpolation origin.
        # Ordinary callers keep their existing feedforward behavior.
        if move_tau_ff_initializer is not None:
            move_tau_ff = move_tau_ff_initializer(dict(starts))
        if move_reference_starts is not None:
            if set(move_reference_starts)!=set(starts) or not all(
                    math.isfinite(float(q)) for q in move_reference_starts.values()):
                raise ValueError('invalid continued interpolation references')
            starts={n:float(move_reference_starts[n]) for n in active_names}
        dynamics = begin_motion(self, active_names + list(hold_targets))
        if move_boundary_keepalive is not None:move_boundary_keepalive()
        hold_tau = hold_tau or {}
        progress_windows = progress_windows or {}
        pre_window_gains = pre_window_gains or {}
        velocity_ff_joints = velocity_ff_joints or set()
        move_tau_ff = move_tau_ff or {}
        if trajectory == "linear":
            trajectory_fn = lambda value: max(0.0, min(1.0, value))
            trajectory_derivative_fn = lambda value: 1.0
        elif trajectory == "blend_smootherstep":
            trajectory_fn = lambda value: blend_smootherstep(value, linear_blend)
            trajectory_derivative_fn = lambda value: blend_smootherstep_derivative(value, linear_blend)
        elif trajectory == "smootherstep":
            trajectory_fn = smootherstep
            trajectory_derivative_fn = smootherstep_derivative
        else:
            trajectory_fn = smoothstep
            trajectory_derivative_fn = lambda value: 6.0 * value * (1.0 - value)

        if step_deg > 0:
            steps = max(
                int(math.ceil(abs(math.degrees(targets[name] - starts[name])) / step_deg))
                for name in active_names
            )
        else:
            steps = 1
        steps = max(1, steps)

        def active_tau_for_progress(name: str, progress: float) -> float:
            config = move_tau_ff.get(name, 0.0)
            if not isinstance(config, dict):
                return float(config)
            start_tau = float(config.get("start_tau", config.get("tau", 0.0)))
            end_tau = float(config.get("end_tau", config.get("tau", start_tau)))
            ramp_fraction = max(1e-6, float(config.get("ramp_fraction", 1.0)))
            ramp_progress = max(0.0, min(1.0, progress / ramp_fraction))
            if config.get("ramp") == "smoothstep":
                ramp_progress = smoothstep(ramp_progress)
            return start_tau * (1.0 - ramp_progress) + end_tau * ramp_progress

        preload_targets = dict(hold_targets)
        preload_targets.update(starts)
        start_time = time.time()
        while time.time() - start_time < preload_seconds:
            for name, target in preload_targets.items():
                if name in starts:
                    gains = move_gains.get(name, {})
                    tau = active_tau_for_progress(name, 0.0)
                else:
                    gains = hold_gains.get(name, {})
                    tau = hold_tau.get(name, 0.0)
                kp = gains.get("kp", fallback_kp)
                kd = gains.get("kd", fallback_kd)
                self.ctrl.controlMIT(self.motors[name], kp, kd, target, 0, tau)
            if watchdog is not None:
                watchdog(preload_targets)
            time.sleep(0.02)

        previous = dict(starts)
        for step in range(1, steps + 1):
            intermediates = {
                name: starts[name] + (targets[name] - starts[name]) * (step / steps)
                for name in active_names
            }
            print(
                "v2.2 continuous group step",
                ",".join(active_names),
                f"{step}/{steps}",
                "targets=",
                json.dumps(intermediates, ensure_ascii=False),
            )
            step_start = time.time()
            while time.time() - step_start < seconds_per_step:
                t = (time.time() - step_start) / max(seconds_per_step, 1e-6)
                s = trajectory_fn(t)
                ds_dt = trajectory_derivative_fn(t) / max(seconds_per_step, 1e-6)
                commands = []
                reference_velocities = dict.fromkeys(active_names + list(hold_targets), 0.0)
                reference_accelerations = dict(reference_velocities)
                for name in active_names:
                    gains = move_gains.get(name, {})
                    active_velocity = 0.0
                    if name in progress_windows:
                        window_start, window_end = progress_windows[name]
                        local_s = (s - window_start) / max(window_end - window_start, 1e-6)
                        local_s = smoothstep(local_s)
                        if s < window_start:
                            gains = pre_window_gains.get(name, gains)
                    else:
                        local_s = s
                        if name in velocity_ff_joints:
                            active_velocity = (intermediates[name] - previous[name]) * ds_dt
                    kp = gains.get("kp", fallback_kp)
                    kd = gains.get("kd", fallback_kd)
                    target = previous[name] * (1.0 - local_s) + intermediates[name] * local_s
                    ds, dds = reference_derivatives(trajectory, t, max(seconds_per_step, 1e-6),
                                                    linear_blend, progress_windows.get(name))
                    reference_velocities[name] = (intermediates[name]-previous[name])*ds
                    reference_accelerations[name] = (intermediates[name]-previous[name])*dds
                    active_tau = active_tau_for_progress(name, t)
                    commands.append((name, kp, kd, target, active_velocity, active_tau))
                for hold_name, hold_target in hold_targets.items():
                    gains = hold_gains.get(hold_name, {})
                    kp = gains.get("kp", fallback_kp)
                    kd = gains.get("kd", fallback_kd)
                    commands.append((hold_name, kp, kd, hold_target, 0, hold_tau.get(hold_name, 0.0)))
                prepare_frame(dynamics, {row[0]: row[3] for row in commands}, (step - 1 + t) / steps,
                              reference_velocities, reference_accelerations)
                for command in commands:
                    send_command(self, dynamics, *command)
                if watchdog is not None:
                    watchdog({row[0]: row[3] for row in commands})
                time.sleep(control_dt)
            previous = intermediates

        final_targets = dict(hold_targets)
        final_targets.update(targets)
        start_time = time.time()
        while time.time() - start_time < 0.5:
            prepare_frame(dynamics, final_targets, 1.0, dict.fromkeys(final_targets, 0.0), dict.fromkeys(final_targets, 0.0))
            for name, target in final_targets.items():
                if name in targets:
                    gains = move_gains.get(name, {})
                    tau = active_tau_for_progress(name, 1.0)
                else:
                    gains = hold_gains.get(name, {})
                    tau = hold_tau.get(name, 0.0)
                kp = gains.get("kp", fallback_kp)
                kd = gains.get("kd", fallback_kd)
                send_command(self, dynamics, name, kp, kd, target, 0, tau)
            if watchdog is not None:
                watchdog(final_targets)
            time.sleep(0.02)
        finish_motion(dynamics)


def load_home(path: str = HOME_PATH) -> Dict[str, float]:
    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)
    joints = payload.get("joints")
    if not isinstance(joints, dict):
        raise RuntimeError("invalid v2 home file: " + path)
    return {name: float(value) for name, value in joints.items()}


def load_pose(path: str) -> Dict[str, float]:
    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)
    joints = payload.get("joints")
    if not isinstance(joints, dict):
        raise RuntimeError("invalid v2 pose file: " + path)
    return {name: float(value) for name, value in joints.items()}


def save_home(home: Dict[str, float], note: str, path: str = HOME_PATH) -> None:
    payload = {
        "type": "left_arm_v2_home",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "note": note,
        "joint_order": list(home.keys()),
        "joints": home,
    }
    ensure_parent(path)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print("saved v2 home:", path)
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def save_pose(pose_type: str, pose: Dict[str, float], note: str, path: str) -> None:
    payload = {
        "type": pose_type,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "note": note,
        "joint_order": list(pose.keys()),
        "joints": pose,
    }
    ensure_parent(path)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print("saved v2 pose:", path)
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def clearance_hold_plan_for(
    active: str,
    ordered: List[str],
    current: Dict[str, float],
    completed_targets: Dict[str, float],
) -> Tuple[Dict[str, float], Dict[str, Dict[str, float]]]:
    strong_hold_names = set(completed_targets.keys())
    compliant_hold_names = set(CLEARANCE_COMPLIANT_HOLDS_BY_ACTIVE.get(active, set()))
    strong_hold_names.difference_update(compliant_hold_names)

    if active == "shoulder_front":
        strong_hold_names.update(["elbow"])
    elif active == "shoulder_side":
        strong_hold_names.update(["shoulder_front", "elbow"])
    elif active == "elbow":
        strong_hold_names.update(["shoulder_front", "shoulder_side"])
    elif active in ("arm_roll", "wrist_side", "wrist"):
        strong_hold_names.update(["shoulder_front", "shoulder_side", "elbow"])

    hold_targets = {}
    hold_gains = {}
    for hold_name in ordered:
        if hold_name == active:
            continue
        hold_targets[hold_name] = completed_targets.get(hold_name, current[hold_name])
        if hold_name in compliant_hold_names:
            hold_gains[hold_name] = CLEARANCE_COMPLIANT_HOLD_GAINS.get(
                hold_name,
                CLEARANCE_BASE_HOLD_GAINS[hold_name],
            )
        elif hold_name in strong_hold_names:
            hold_gains[hold_name] = CLEARANCE_HOLD_GAINS.get(hold_name, CLEARANCE_BASE_HOLD_GAINS[hold_name])
        else:
            hold_gains[hold_name] = CLEARANCE_BASE_HOLD_GAINS[hold_name]
    return hold_targets, hold_gains


def home_hold_plan_for(
    active: str,
    ordered: List[str],
    current: Dict[str, float],
    completed_targets: Dict[str, float],
) -> Tuple[Dict[str, float], Dict[str, Dict[str, float]]]:
    strong_hold_names = set(completed_targets.keys())
    compliant_hold_names = set(HOME_COMPLIANT_HOLDS_BY_ACTIVE.get(active, set()))
    strong_hold_names.difference_update(compliant_hold_names)

    if active == "elbow":
        strong_hold_names.update(["shoulder_front", "shoulder_side"])
    elif active == "shoulder_front":
        strong_hold_names.update(["elbow", "shoulder_side"])
    elif active in ("wrist", "wrist_side", "arm_roll"):
        strong_hold_names.update(["elbow", "shoulder_front"])

    hold_targets = {}
    hold_gains = {}
    for hold_name in ordered:
        if hold_name == active:
            continue
        hold_targets[hold_name] = completed_targets.get(hold_name, current[hold_name])
        if hold_name in compliant_hold_names:
            hold_gains[hold_name] = HOME_COMPLIANT_HOLD_GAINS.get(
                hold_name,
                HOME_BASE_HOLD_GAINS[hold_name],
            )
        elif hold_name in strong_hold_names:
            hold_gains[hold_name] = HOME_HOLD_GAINS.get(hold_name, HOME_BASE_HOLD_GAINS[hold_name])
        else:
            hold_gains[hold_name] = HOME_BASE_HOLD_GAINS[hold_name]
    return hold_targets, hold_gains


def prehome_clearance_gains_for(name: str, fallback_kp: float, fallback_kd: float) -> Dict[str, float]:
    if name in PREHOME_CLEARANCE_GAINS:
        return PREHOME_CLEARANCE_GAINS[name]
    result = NUDGE_GAINS.get(name, CLEARANCE_MOVE_GAINS.get(name, {"kp": fallback_kp, "kd": fallback_kd}))
    if name == 'shoulder_rotate':
        result = dict(result, kp=min(36.,result['kp']), kd=min(4.5,result['kd']))
    return result


def prehome_clearance_seconds_for(name: str, delta_deg: float) -> float:
    default_base = 6.0 if name == "wrist" else 2.2
    base = PREHOME_CLEARANCE_BASE_SECONDS.get(name, NUDGE_MIN_SECONDS.get(name, default_base))
    seconds_per_deg = PREHOME_CLEARANCE_SECONDS_PER_DEG.get(name)
    if seconds_per_deg is not None:
        base = max(base, abs(delta_deg) * seconds_per_deg)
    seconds = min(PREHOME_CLEARANCE_MAX_SECONDS.get(name, 20.0), base)
    if name == 'wrist':
        # Unlike the old six-second constant, scale a large return from any
        # board pose. 1.875 bounds all supported interpolation derivatives.
        seconds = max(seconds,1.875*abs(math.radians(delta_deg))/.2)
    return seconds


def prehome_clearance_hold_gains_for(
    active: str,
    hold_names: Iterable[str],
    fallback_kp: float,
    fallback_kd: float,
) -> Dict[str, Dict[str, float]]:
    hold_gains = {
        hold_name: CLEARANCE_HOLD_GAINS.get(
            hold_name,
            CLEARANCE_BASE_HOLD_GAINS.get(hold_name, {"kp": fallback_kp, "kd": fallback_kd}),
        )
        for hold_name in hold_names
    }
    for compliant_name in CLEARANCE_COMPLIANT_HOLDS_BY_ACTIVE.get(active, set()):
        if compliant_name in hold_gains:
            hold_gains[compliant_name] = CLEARANCE_COMPLIANT_HOLD_GAINS[compliant_name]
    nudge_compliant_gains = NUDGE_COMPLIANT_HOLD_GAINS_BY_ACTIVE.get(active, NUDGE_COMPLIANT_HOLD_GAINS)
    for compliant_name in NUDGE_COMPLIANT_HOLDS_BY_ACTIVE.get(active, set()):
        if compliant_name in hold_gains:
            hold_gains[compliant_name] = nudge_compliant_gains[compliant_name]
    if 'shoulder_rotate' in hold_gains:
        row = hold_gains['shoulder_rotate']
        hold_gains['shoulder_rotate'] = dict(row,kp=min(36.,row['kp']),kd=min(4.5,row['kd']))
    return hold_gains


def prehome_load_transfer(status, active_gains, end_tau, hold_targets, hold_gains,
                         fallback_kp, fallback_kd):
    """Match measured support at stage entry; retain trained active end torque."""
    from left_arm_v3_1_model_control import MIT_TAU_MAX
    moving,holding,audit={},{},{}
    for name,gains in active_gains.items():
        row=status[name];kd=float(gains.get('kd',fallback_kd))
        start=float(row['tau'])+kd*float(row['vel'])
        end=float(end_tau.get(name,0.))
        if not all(math.isfinite(v) for v in (start,end)) or max(abs(start),abs(end))>MIT_TAU_MAX[name]:
            raise ValueError('invalid prehome entry torque for '+name)
        moving[name]={'start_tau':start,'end_tau':end,'ramp_fraction':1.,'ramp':'smoothstep'}
        audit[name]={'mode':'measured-entry-to-trained-end','start_tau':start,'end_tau':end}
    for name,target in hold_targets.items():
        row=status[name];gains=hold_gains.get(name,{})
        kp=float(gains.get('kp',fallback_kp));kd=float(gains.get('kd',fallback_kd))
        tau=float(row['tau'])-kp*(float(target)-float(row['pos']))+kd*float(row['vel'])
        if not math.isfinite(tau) or abs(tau)>MIT_TAU_MAX[name]:
            raise ValueError('invalid prehome hold torque for '+name)
        holding[name]=tau
        audit[name]={'mode':'current-fixed-pose-support','tau_ff':tau,'nominal_hold_target':target}
    return moving,holding,audit


def clamp_tau(name: str, tau: float, limits: Dict[str, Tuple[float, float]]) -> float:
    if name not in limits:
        return tau
    low, high = limits[name]
    return max(low, min(high, tau))


def load_adaptive_hold_tau(path: str = ADAPTIVE_HOLD_TAU_PATH) -> dict:
    if not os.path.exists(path):
        return {"type": "left_arm_v2_6_adaptive_hold_tau", "rules": {}}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if "rules" not in data or not isinstance(data["rules"], dict):
        raise RuntimeError(f"invalid adaptive hold tau file: {path}")
    return data


def save_adaptive_hold_tau(data: dict, path: str = ADAPTIVE_HOLD_TAU_PATH) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    data["type"] = "left_arm_v2_6_adaptive_hold_tau"
    data["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.write("\n")


def load_adaptive_active_tau(path: str = ADAPTIVE_ACTIVE_TAU_PATH) -> dict:
    if not os.path.exists(path):
        return {"type": "left_arm_v2_6_adaptive_active_tau", "rules": {}}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if "rules" not in data or not isinstance(data["rules"], dict):
        raise RuntimeError(f"invalid adaptive active tau file: {path}")
    return data


def save_adaptive_active_tau(data: dict, path: str = ADAPTIVE_ACTIVE_TAU_PATH) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    data["type"] = "left_arm_v2_6_adaptive_active_tau"
    data["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.write("\n")


def load_adaptive_target_bias(path: str = ADAPTIVE_TARGET_BIAS_PATH) -> dict:
    if not os.path.exists(path):
        return {"type": "left_arm_v2_6_adaptive_target_bias", "rules": {}}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if "rules" not in data or not isinstance(data["rules"], dict):
        raise RuntimeError(f"invalid adaptive target bias file: {path}")
    return data


def save_adaptive_target_bias(data: dict, path: str = ADAPTIVE_TARGET_BIAS_PATH) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    data["type"] = "left_arm_v2_6_adaptive_target_bias"
    data["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.write("\n")


def load_adaptive_hold_target_bias(path: str = ADAPTIVE_HOLD_TARGET_BIAS_PATH) -> dict:
    if not os.path.exists(path):
        return {"type": "left_arm_v2_6_adaptive_hold_target_bias", "rules": {}}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if "rules" not in data or not isinstance(data["rules"], dict):
        raise RuntimeError(f"invalid adaptive hold target bias file: {path}")
    return data


def save_adaptive_hold_target_bias(data: dict, path: str = ADAPTIVE_HOLD_TARGET_BIAS_PATH) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    data["type"] = "left_arm_v2_6_adaptive_hold_target_bias"
    data["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.write("\n")


def adaptive_posture_key(low_shoulder_front: bool) -> Optional[str]:
    return LOW_SHOULDER_POSTURE if low_shoulder_front else None


def adaptive_target_bias_for(
    joint: str,
    low_shoulder_front: bool = False,
    path: str = ADAPTIVE_TARGET_BIAS_PATH,
) -> float:
    posture = adaptive_posture_key(low_shoulder_front)
    if posture is None:
        return 0.0
    data = load_adaptive_target_bias(path)
    record = data.get("rules", {}).get(posture, {}).get(joint)
    if not record:
        return 0.0
    bias_deg = record.get("bias_deg") if isinstance(record, dict) else record
    if bias_deg is None:
        return 0.0
    return math.radians(max(-ADAPTIVE_TARGET_BIAS_LIMIT_DEG, min(ADAPTIVE_TARGET_BIAS_LIMIT_DEG, float(bias_deg))))


def adaptive_hold_target_bias_for(
    active: str,
    hold_targets: Dict[str, float],
    low_shoulder_front: bool = False,
    path: str = ADAPTIVE_HOLD_TARGET_BIAS_PATH,
) -> Dict[str, float]:
    posture = adaptive_posture_key(low_shoulder_front)
    if posture is None:
        return {}
    data = load_adaptive_hold_target_bias(path)
    active_rules = data.get("rules", {}).get(posture, {}).get(active, {})
    if not active_rules:
        return {}
    offsets = {}
    for hold_name, record in active_rules.items():
        if hold_name not in hold_targets:
            continue
        bias_deg = record.get("bias_deg") if isinstance(record, dict) else record
        if bias_deg is None:
            continue
        offsets[hold_name] = math.radians(
            max(-ADAPTIVE_HOLD_TARGET_BIAS_LIMIT_DEG, min(ADAPTIVE_HOLD_TARGET_BIAS_LIMIT_DEG, float(bias_deg)))
        )
    return offsets


def update_adaptive_hold_target_bias(
    active: str,
    induced_errors_deg: Dict[str, float],
    low_shoulder_front: bool = False,
    path: str = ADAPTIVE_HOLD_TARGET_BIAS_PATH,
    label: str = "",
) -> Dict[str, dict]:
    posture = adaptive_posture_key(low_shoulder_front)
    if posture is None:
        return {}
    data = load_adaptive_hold_target_bias(path)
    rules = data.setdefault("rules", {}).setdefault(posture, {}).setdefault(active, {})
    updates = {}
    for hold_name, error_deg in induced_errors_deg.items():
        if abs(error_deg) < ADAPTIVE_TARGET_BIAS_ERROR_DEADBAND_DEG:
            continue
        previous = rules.get(hold_name, {})
        has_previous = isinstance(previous, dict) and bool(previous)
        current_bias = float(previous.get("bias_deg", 0.0)) if has_previous else float(previous or 0.0)
        previous_error = abs(float(previous.get("last_error_deg", error_deg))) if has_previous else None
        best_error = (
            abs(float(previous.get("best_error_deg", previous.get("last_error_deg", error_deg))))
            if has_previous
            else abs(error_deg)
        )
        best_bias = float(previous.get("best_bias_deg", current_bias)) if has_previous else current_bias
        step_scale = float(previous.get("step_scale", 1.0)) if has_previous else 1.0
        abs_error = abs(error_deg)
        improved = abs_error < best_error - ADAPTIVE_HOLD_TAU_IMPROVEMENT_DEADBAND_DEG
        refined_best = abs_error < best_error
        worse = (
            previous_error is not None
            and abs_error > previous_error + ADAPTIVE_HOLD_TAU_IMPROVEMENT_DEADBAND_DEG
        )
        if refined_best:
            best_error = abs_error
            best_bias = current_bias
        if improved:
            base_bias = current_bias
        elif worse:
            base_bias = best_bias
            step_scale = max(ADAPTIVE_HOLD_TAU_MIN_STEP_SCALE, step_scale * 0.5)
        elif previous_error is not None:
            base_bias = best_bias
            step_scale = max(ADAPTIVE_HOLD_TAU_MIN_STEP_SCALE, step_scale * 0.8)
        else:
            base_bias = current_bias
        if has_previous and (worse or (previous_error is not None and not refined_best)):
            new_bias = best_bias
        else:
            delta_bias = max(
                -ADAPTIVE_HOLD_TARGET_BIAS_MAX_STEP_DEG * step_scale,
                min(
                    ADAPTIVE_HOLD_TARGET_BIAS_MAX_STEP_DEG * step_scale,
                    error_deg * ADAPTIVE_HOLD_TARGET_BIAS_STEP_SCALE * step_scale,
                ),
            )
            new_bias = max(
                -ADAPTIVE_HOLD_TARGET_BIAS_LIMIT_DEG,
                min(ADAPTIVE_HOLD_TARGET_BIAS_LIMIT_DEG, base_bias + delta_bias),
            )
        if new_bias == current_bias:
            continue
        record = {
            "bias_deg": new_bias,
            "previous_bias_deg": current_bias,
            "base_bias_deg": base_bias,
            "delta_bias_deg": new_bias - current_bias,
            "last_error_deg": error_deg,
            "best_error_deg": best_error,
            "best_bias_deg": best_bias,
            "step_scale": step_scale,
            "learning_state": "improved" if improved else "backoff" if worse else "plateau",
            "refined_best": refined_best,
            "samples": int(previous.get("samples", 0)) + 1 if has_previous else 1,
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        }
        if label:
            record["label"] = label
        rules[hold_name] = record
        updates[hold_name] = record
    if updates:
        save_adaptive_hold_target_bias(data, path)
    return updates


def update_adaptive_target_bias(
    final_errors_deg: Dict[str, float],
    low_shoulder_front: bool = False,
    path: str = ADAPTIVE_TARGET_BIAS_PATH,
    label: str = "",
    force_joints: Optional[Iterable[str]] = None,
    require_ready: bool = True,
) -> Dict[str, dict]:
    posture = adaptive_posture_key(low_shoulder_front)
    if posture is None:
        return {}
    data = load_adaptive_target_bias(path)
    rules = data.setdefault("rules", {}).setdefault(posture, {})
    updates = {}
    forced = set(force_joints or [])
    for joint, error_deg in final_errors_deg.items():
        if abs(error_deg) < ADAPTIVE_TARGET_BIAS_ERROR_DEADBAND_DEG:
            continue
        if require_ready and joint not in forced and not adaptive_target_bias_ready_for(joint, error_deg, low_shoulder_front):
            continue
        previous = rules.get(joint, {})
        current_bias = float(previous.get("bias_deg", 0.0)) if isinstance(previous, dict) else float(previous or 0.0)
        previous_error = abs(float(previous.get("last_error_deg", error_deg))) if isinstance(previous, dict) else None
        best_error = (
            abs(float(previous.get("best_error_deg", previous.get("last_error_deg", error_deg))))
            if isinstance(previous, dict)
            else abs(error_deg)
        )
        best_bias = float(previous.get("best_bias_deg", current_bias)) if isinstance(previous, dict) else current_bias
        step_scale = float(previous.get("step_scale", 1.0)) if isinstance(previous, dict) else 1.0
        improved = abs(error_deg) < best_error - ADAPTIVE_HOLD_TAU_IMPROVEMENT_DEADBAND_DEG
        worse = (
            previous_error is not None
            and abs(error_deg) > previous_error + ADAPTIVE_HOLD_TAU_IMPROVEMENT_DEADBAND_DEG
        )
        if improved:
            best_error = abs(error_deg)
            best_bias = current_bias
        elif worse:
            current_bias = best_bias
            step_scale = max(ADAPTIVE_HOLD_TAU_MIN_STEP_SCALE, step_scale * 0.5)
        elif previous_error is not None:
            step_scale = max(ADAPTIVE_HOLD_TAU_MIN_STEP_SCALE, step_scale * 0.8)
        delta_bias = max(
            -ADAPTIVE_TARGET_BIAS_MAX_STEP_DEG * step_scale,
            min(ADAPTIVE_TARGET_BIAS_MAX_STEP_DEG * step_scale, error_deg * ADAPTIVE_TARGET_BIAS_STEP_SCALE * step_scale),
        )
        new_bias = max(-ADAPTIVE_TARGET_BIAS_LIMIT_DEG, min(ADAPTIVE_TARGET_BIAS_LIMIT_DEG, current_bias + delta_bias))
        if new_bias == current_bias:
            continue
        record = {
            "bias_deg": new_bias,
            "previous_bias_deg": current_bias,
            "delta_bias_deg": new_bias - current_bias,
            "last_error_deg": error_deg,
            "best_error_deg": best_error,
            "best_bias_deg": best_bias,
            "step_scale": step_scale,
            "learning_state": "improved" if improved else "backoff" if worse else "plateau",
            "samples": int(previous.get("samples", 0)) + 1 if isinstance(previous, dict) else 1,
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        }
        if label:
            record["label"] = label
        rules[joint] = record
        updates[joint] = record
    if updates:
        save_adaptive_target_bias(data, path)
    return updates


def adaptive_target_bias_ready_for(
    joint: str,
    error_deg: float,
    low_shoulder_front: bool = False,
) -> bool:
    if adaptive_hold_tau_converged_for(joint, low_shoulder_front):
        return True
    return abs(error_deg) < ADAPTIVE_HOLD_TAU_ERROR_DEADBAND_DEG


def adaptive_hold_tau_for(
    active: str,
    hold_targets: Dict[str, float],
    hold_tau: Dict[str, float],
    low_shoulder_front: bool = False,
    path: str = ADAPTIVE_HOLD_TAU_PATH,
) -> Dict[str, float]:
    posture = adaptive_posture_key(low_shoulder_front)
    if posture is None:
        return hold_tau
    data = load_adaptive_hold_tau(path)
    active_rules = data.get("rules", {}).get(posture, {}).get(active, {})
    if not active_rules:
        return hold_tau
    adapted = dict(hold_tau)
    for hold_name, record in active_rules.items():
        if hold_name not in hold_targets:
            continue
        tau = record.get("tau") if isinstance(record, dict) else record
        if tau is None:
            continue
        adapted[hold_name] = clamp_tau(hold_name, float(tau), HOLD_TAU_LIMITS)
    return adapted


def adaptive_active_tau_for(
    name: str,
    delta_deg: float,
    active_tau: float,
    low_shoulder_front: bool = False,
    path: str = ADAPTIVE_ACTIVE_TAU_PATH,
) -> float:
    posture = adaptive_posture_key(low_shoulder_front)
    if posture is None or name not in ACTIVE_TAU_LIMITS:
        return clamp_tau(name, active_tau, ACTIVE_TAU_LIMITS)
    data = load_adaptive_active_tau(path)
    direction = direction_key(delta_deg)
    record = data.get("rules", {}).get(posture, {}).get(name, {}).get(direction, {})
    if not record:
        return clamp_tau(name, active_tau, ACTIVE_TAU_LIMITS)
    tau = record.get("tau") if isinstance(record, dict) else record
    if tau is None:
        return clamp_tau(name, active_tau, ACTIVE_TAU_LIMITS)
    return clamp_tau(name, float(tau), ACTIVE_TAU_LIMITS)


def update_adaptive_active_tau(
    name: str,
    delta_deg: float,
    active_error_deg: float,
    applied_tau: float,
    low_shoulder_front: bool = False,
    path: str = ADAPTIVE_ACTIVE_TAU_PATH,
    label: str = "",
    error_deadband_deg: float = ADAPTIVE_ACTIVE_TAU_ERROR_DEADBAND_DEG,
) -> Dict[str, dict]:
    posture = adaptive_posture_key(low_shoulder_front)
    if posture is None or name not in ACTIVE_TAU_LIMITS or abs(active_error_deg) < error_deadband_deg:
        return {}
    data = load_adaptive_active_tau(path)
    direction = direction_key(delta_deg)
    rules = data.setdefault("rules", {}).setdefault(posture, {}).setdefault(name, {})
    previous = rules.get(direction, {})
    has_previous = isinstance(previous, dict) and bool(previous)
    current_tau = float(applied_tau)
    previous_error = abs(float(previous.get("last_error_deg", active_error_deg))) if has_previous else None
    best_error = (
        abs(float(previous.get("best_error_deg", previous.get("last_error_deg", active_error_deg))))
        if has_previous
        else abs(active_error_deg)
    )
    best_tau = float(previous.get("best_tau", current_tau)) if has_previous else current_tau
    step_scale = float(previous.get("step_scale", 1.0)) if has_previous else 1.0
    abs_error = abs(active_error_deg)
    improved = abs_error < best_error - ADAPTIVE_ACTIVE_TAU_IMPROVEMENT_DEADBAND_DEG
    refined_best = abs_error < best_error
    worse = previous_error is not None and abs_error > previous_error + ADAPTIVE_ACTIVE_TAU_IMPROVEMENT_DEADBAND_DEG
    if refined_best:
        best_error = abs_error
        best_tau = current_tau
    if improved:
        base_tau = current_tau
    elif worse:
        base_tau = best_tau
        step_scale = max(ADAPTIVE_ACTIVE_TAU_MIN_STEP_SCALE, step_scale * 0.5)
    elif previous_error is not None:
        base_tau = best_tau
        step_scale = max(ADAPTIVE_ACTIVE_TAU_MIN_STEP_SCALE, step_scale * 0.8)
    else:
        base_tau = current_tau
    delta_tau = max(
        -ADAPTIVE_ACTIVE_TAU_MAX_STEP * step_scale,
        min(
            ADAPTIVE_ACTIVE_TAU_MAX_STEP * step_scale,
            active_error_deg * ADAPTIVE_ACTIVE_TAU_STEP_PER_DEG * step_scale,
        ),
    )
    new_tau = clamp_tau(name, base_tau + delta_tau, ACTIVE_TAU_LIMITS)
    if new_tau == base_tau:
        return {}
    record = {
        "tau": new_tau,
        "previous_tau": base_tau,
        "applied_tau": current_tau,
        "delta_tau": new_tau - base_tau,
        "direction": direction,
        "last_error_deg": active_error_deg,
        "best_error_deg": best_error,
        "best_tau": best_tau,
        "step_scale": step_scale,
        "learning_state": "improved" if improved else "backoff" if worse else "plateau",
        "refined_best": refined_best,
        "samples": int(previous.get("samples", 0)) + 1 if has_previous else 1,
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
    }
    if label:
        record["label"] = label
    rules[direction] = record
    save_adaptive_active_tau(data, path)
    return {f"{name}:{direction}": record}


def update_adaptive_hold_tau(
    active: str,
    hold_errors_deg: Dict[str, float],
    hold_tau: Dict[str, float],
    low_shoulder_front: bool = False,
    path: str = ADAPTIVE_HOLD_TAU_PATH,
    label: str = "",
    error_deadband_deg: float = ADAPTIVE_HOLD_TAU_ERROR_DEADBAND_DEG,
) -> Dict[str, dict]:
    posture = adaptive_posture_key(low_shoulder_front)
    if posture is None:
        return {}
    data = load_adaptive_hold_tau(path)
    rules = data.setdefault("rules", {}).setdefault(posture, {}).setdefault(active, {})
    updates = {}
    for hold_name, error_deg in hold_errors_deg.items():
        if hold_name not in hold_tau or abs(error_deg) < error_deadband_deg:
            continue
        applied_tau = float(hold_tau[hold_name])
        current_tau = applied_tau
        previous = rules.get(hold_name, {})
        previous_error = abs(float(previous.get("last_error_deg", error_deg))) if isinstance(previous, dict) else None
        best_error = (
            abs(float(previous.get("best_error_deg", previous.get("last_error_deg", error_deg))))
            if isinstance(previous, dict)
            else abs(error_deg)
        )
        best_tau = float(previous.get("best_tau", current_tau)) if isinstance(previous, dict) else current_tau
        step_scale = float(previous.get("step_scale", 1.0)) if isinstance(previous, dict) else 1.0
        if (
            isinstance(previous, dict)
            and previous
            and step_scale <= ADAPTIVE_HOLD_TAU_MIN_STEP_SCALE
            and best_error <= ADAPTIVE_HOLD_TAU_TARGET_BIAS_HANDOFF_DEG
            and abs(error_deg) <= ADAPTIVE_HOLD_TAU_TARGET_BIAS_HANDOFF_DEG
        ):
            continue
        previous_successful_direction = float(previous.get("successful_direction", 0.0)) if isinstance(previous, dict) else 0.0
        previous_delta = float(previous.get("delta_tau", 0.0)) if isinstance(previous, dict) else 0.0
        tau_low, tau_high = HOLD_TAU_LIMITS.get(hold_name, (-float("inf"), float("inf")))
        if tau_high <= 0.0:
            correction_direction = -1.0 if error_deg >= 0.0 else 1.0
        elif tau_low >= 0.0:
            correction_direction = 1.0 if error_deg >= 0.0 else -1.0
        else:
            correction_direction = 1.0 if error_deg >= 0.0 else -1.0
        if previous_successful_direction:
            search_direction = previous_successful_direction
        elif best_tau != applied_tau:
            search_direction = 1.0 if best_tau > applied_tau else -1.0
        elif previous_delta:
            search_direction = 1.0 if previous_delta > 0.0 else -1.0
        else:
            search_direction = correction_direction
        abs_error = abs(error_deg)
        improved = abs_error < best_error - ADAPTIVE_HOLD_TAU_IMPROVEMENT_DEADBAND_DEG
        refined_best = abs_error < best_error
        worse = (
            previous_error is not None
            and abs_error > previous_error + ADAPTIVE_HOLD_TAU_IMPROVEMENT_DEADBAND_DEG
        )
        improved_recent = (
            previous_error is not None
            and abs_error < previous_error - ADAPTIVE_HOLD_TAU_IMPROVEMENT_DEADBAND_DEG
        )
        if refined_best:
            best_error = abs_error
            best_tau = applied_tau
            if previous_delta:
                search_direction = 1.0 if previous_delta > 0.0 else -1.0
        elif improved_recent and previous_delta:
            search_direction = 1.0 if previous_delta > 0.0 else -1.0
        if improved or improved_recent:
            current_tau = applied_tau
        elif worse:
            current_tau = best_tau
            step_scale = max(ADAPTIVE_HOLD_TAU_MIN_STEP_SCALE, step_scale * 0.5)
        elif previous_error is not None and previous_successful_direction and not worse:
            current_tau = applied_tau
            step_scale = max(ADAPTIVE_HOLD_TAU_MIN_STEP_SCALE, step_scale * 0.8)
        elif previous_error is not None:
            current_tau = best_tau
            step_scale = max(ADAPTIVE_HOLD_TAU_MIN_STEP_SCALE, step_scale * 0.8)
        delta_tau_mag = min(
            ADAPTIVE_HOLD_TAU_MAX_STEP * step_scale,
            max(
                ADAPTIVE_HOLD_TAU_MIN_EXPLORATION_STEP,
                abs_error * ADAPTIVE_HOLD_TAU_STEP_PER_DEG * step_scale,
            ),
        )
        delta_tau = search_direction * delta_tau_mag
        if worse or (
            previous_error is not None
            and not refined_best
            and not improved_recent
            and not previous_successful_direction
        ):
            new_tau = clamp_tau(hold_name, best_tau + delta_tau, HOLD_TAU_LIMITS)
        else:
            new_tau = clamp_tau(hold_name, current_tau + delta_tau, HOLD_TAU_LIMITS)
        if new_tau == applied_tau:
            continue
        record = {
            "tau": new_tau,
            "previous_tau": applied_tau,
            "base_tau": current_tau,
            "applied_tau": applied_tau,
            "delta_tau": new_tau - applied_tau,
            "search_direction": search_direction,
            "successful_direction": search_direction if (refined_best or improved_recent) else previous_successful_direction,
            "last_error_deg": error_deg,
            "best_error_deg": best_error,
            "best_tau": best_tau,
            "step_scale": step_scale,
            "learning_state": "improved" if improved else "recent_improved" if improved_recent else "backoff" if worse else "plateau",
            "refined_best": refined_best,
            "samples": int(previous.get("samples", 0)) + 1 if isinstance(previous, dict) else 1,
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        }
        if label:
            record["label"] = label
        rules[hold_name] = record
        updates[hold_name] = record
    if updates:
        save_adaptive_hold_tau(data, path)
    return updates


def adaptive_hold_tau_converged_for(
    hold_name: str,
    low_shoulder_front: bool = False,
    path: str = ADAPTIVE_HOLD_TAU_PATH,
) -> bool:
    posture = adaptive_posture_key(low_shoulder_front)
    if posture is None:
        return False
    data = load_adaptive_hold_tau(path)
    posture_rules = data.get("rules", {}).get(posture, {})
    for active_rules in posture_rules.values():
        record = active_rules.get(hold_name) if isinstance(active_rules, dict) else None
        if adaptive_hold_tau_record_converged(record):
            return True
    return False


def adaptive_hold_tau_record_converged(record: object) -> bool:
    if not isinstance(record, dict):
        return False
    samples = int(record.get("samples", 0))
    state = record.get("learning_state", "")
    return samples >= ADAPTIVE_TARGET_BIAS_MIN_HOLD_TAU_SAMPLES and state in ("plateau", "backoff")


def hold_tau_update_waits_for_more_holding(update: object) -> bool:
    if not isinstance(update, dict) or not update:
        return False
    state = str(update.get("learning_state", ""))
    return bool(update.get("refined_best")) or state in ("improved", "recent_improved")


def adaptive_hold_tau_converged_for_active(
    active: str,
    hold_name: str,
    low_shoulder_front: bool = False,
    path: str = ADAPTIVE_HOLD_TAU_PATH,
) -> bool:
    posture = adaptive_posture_key(low_shoulder_front)
    if posture is None:
        return False
    data = load_adaptive_hold_tau(path)
    record = data.get("rules", {}).get(posture, {}).get(active, {}).get(hold_name)
    return adaptive_hold_tau_record_converged(record)


def direction_key(delta_deg: float) -> str:
    return "positive" if delta_deg >= 0 else "negative"


def nudge_hold_tau_for(
    active: str,
    hold_targets: Dict[str, float],
    low_shoulder_front: bool = False,
    adaptive_active: Optional[str] = None,
    use_adaptive: bool = True,
) -> Dict[str, float]:
    hold_tau = {
        hold_name: clamp_tau(hold_name, tau, HOLD_TAU_LIMITS)
        for hold_name, tau in HOLD_TAU_RULES["base"].items()
    }
    if low_shoulder_front:
        low_rules = HOLD_TAU_RULES[LOW_SHOULDER_POSTURE]
        for hold_name, tau in low_rules.get("*", {}).items():
            if hold_name in hold_targets:
                hold_tau[hold_name] = clamp_tau(hold_name, tau, HOLD_TAU_LIMITS)
        for hold_name, tau in low_rules.get(active, {}).items():
            if hold_name in hold_targets:
                hold_tau[hold_name] = clamp_tau(hold_name, tau, HOLD_TAU_LIMITS)
    if not use_adaptive:
        return hold_tau
    return adaptive_hold_tau_for(adaptive_active or active, hold_targets, hold_tau, low_shoulder_front)


def nudge_active_tau_for(name: str, delta_deg: float, low_shoulder_front: bool = False) -> float:
    direction = direction_key(delta_deg)
    active_tau = ACTIVE_TAU_RULES["base"].get(name, {}).get(direction, 0.0)
    if low_shoulder_front:
        active_tau = ACTIVE_TAU_RULES[LOW_SHOULDER_POSTURE].get(name, {}).get(direction, active_tau)
    return adaptive_active_tau_for(name, delta_deg, active_tau, low_shoulder_front)


def adaptive_hold_gains_for(
    active: str,
    hold_gains: Dict[str, Dict[str, float]],
    low_shoulder_front: bool = False,
) -> Dict[str, Dict[str, float]]:
    if not low_shoulder_front:
        return hold_gains
    rules = POSTURE_HOLD_GAIN_RULES.get(LOW_SHOULDER_POSTURE, {})
    adapted = dict(hold_gains)
    for hold_name, gains in rules.get("*", {}).items():
        if hold_name in adapted:
            adapted[hold_name] = gains
    for hold_name, gains in rules.get(active, {}).items():
        if hold_name in adapted:
            adapted[hold_name] = gains
    return adapted


def is_low_shoulder_front(current: Dict[str, float]) -> bool:
    shoulder_front = current.get("shoulder_front")
    return (
        shoulder_front is not None
        and shoulder_front < NUDGE_WRIST_ACTIVE_LOW_SHOULDER_FRONT_THRESHOLD
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Clean v2 left-arm bring-up controller")
    sub = parser.add_subparsers(dest="cmd", required=True)

    common = ",".join(DEFAULT_JOINTS)

    status = sub.add_parser("status")
    status.add_argument("--joints", default=common)

    restart = sub.add_parser("restart", help="Disable and re-enable selected motors after shaking.")
    restart.add_argument("--joints", default=common)
    restart.add_argument("--off-seconds", type=float, default=0.8)
    restart.add_argument("--hold-seconds", type=float, default=1.0)
    restart.add_argument("--hold-kp", type=float, default=2.0)
    restart.add_argument("--hold-kd", type=float, default=0.4)
    restart.add_argument("--execute", action="store_true")

    hold = sub.add_parser("hold")
    hold.add_argument("--joints", default=common)
    hold.add_argument("--seconds", type=float, default=10.0)
    hold.add_argument("--kp", type=float, default=2.0)
    hold.add_argument("--kd", type=float, default=0.2)

    cap = sub.add_parser("capture-home")
    cap.add_argument("--joints", default=common)
    cap.add_argument("--note", default="")
    cap.add_argument("--home-file", default=HOME_PATH)

    show = sub.add_parser("show-home")
    show.add_argument("--home-file", default=HOME_PATH)

    cap_clearance = sub.add_parser("capture-clearance")
    cap_clearance.add_argument("--joints", default=common)
    cap_clearance.add_argument("--note", default="")
    cap_clearance.add_argument("--clearance-file", default=TABLE_CLEARANCE_PATH)

    show_clearance = sub.add_parser("show-clearance")
    show_clearance.add_argument("--clearance-file", default=TABLE_CLEARANCE_PATH)

    cap_claw = sub.add_parser("capture-claw-home")
    cap_claw.add_argument("--note", default="")
    cap_claw.add_argument("--claw-home-file", default=CLAW_HOME_PATH)

    show_claw = sub.add_parser("show-claw-home")
    show_claw.add_argument("--claw-home-file", default=CLAW_HOME_PATH)

    claw_home = sub.add_parser("claw-home")
    claw_home.add_argument("--claw-home-file", default=CLAW_HOME_PATH)
    claw_home.add_argument("--execute", action="store_true")

    claw_close = sub.add_parser("claw-close")
    claw_close.add_argument("--claw-home-file", default=CLAW_HOME_PATH)
    claw_close.add_argument("--close-offset", type=float, default=CLAW_CLOSE_OFFSET)
    claw_close.add_argument("--no-hold", action="store_true")
    claw_close.add_argument("--execute", action="store_true")

    nudge = sub.add_parser("nudge")
    nudge.add_argument("--joint", required=True)
    nudge.add_argument("--deg", type=float, required=True)
    nudge.add_argument("--seconds", type=float, default=2.0)
    nudge.add_argument("--kp", type=float, default=3.0)
    nudge.add_argument("--kd", type=float, default=0.3)
    nudge.add_argument("--max-deg", type=float, default=5.0)
    nudge.add_argument(
        "--auto-gains",
        action="store_true",
        help="Use verified per-joint nudge gains instead of uniform --kp/--kd.",
    )

    nudge_hold = sub.add_parser("nudge-hold")
    nudge_hold.add_argument("--joint", required=True)
    nudge_hold.add_argument("--deg", type=float, required=True)
    nudge_hold.add_argument("--seconds", type=float, default=2.0)
    nudge_hold.add_argument("--kp", type=float, default=3.0)
    nudge_hold.add_argument("--kd", type=float, default=0.3)
    nudge_hold.add_argument("--max-deg", type=float, default=5.0)
    nudge_hold.add_argument("--hold-joints", default=common)
    nudge_hold.add_argument("--auto-gains", action="store_true")
    nudge_hold.add_argument(
        "--no-active-tau", action="store_true",
        help="Disable active-joint feed-forward torque for a guarded probe.",
    )
    nudge_hold.add_argument(
        "--no-adaptive-learning", action="store_true",
        help="Do not update adaptive files from a guarded probe.",
    )
    nudge_hold.add_argument(
        "--no-adaptive-compensation", action="store_true",
        help="Ignore learned hold torque and target bias during a guarded probe.",
    )
    nudge_hold.add_argument("--max-velocity", type=float)
    nudge_hold.add_argument("--max-position-error-deg", type=float)

    home = sub.add_parser("home")
    home.add_argument("--joints", default=",".join(DEFAULT_HOME_ORDER))
    home.add_argument("--home-file", default=HOME_PATH)
    home.add_argument("--clearance-file", default=TABLE_CLEARANCE_PATH)
    home.add_argument("--seconds", type=float, default=5.0)
    home.add_argument("--kp", type=float, default=3.0)
    home.add_argument("--kd", type=float, default=0.3)
    home.add_argument("--deadband-deg", type=float, default=3.0)
    home.add_argument("--max-delta-deg", type=float, default=20.0)
    home.add_argument(
        "--auto-gains",
        dest="auto_gains",
        action="store_true",
        default=True,
        help="Use verified per-joint home gains. This is the default.",
    )
    home.add_argument(
        "--no-auto-gains",
        dest="auto_gains",
        action="store_false",
        help="Use the uniform --kp/--kd/--seconds values instead.",
    )
    home.add_argument("--execute", action="store_true")
    home.add_argument(
        "--prehome-clearance",
        action="store_true",
        help="Before home, return joints to table clearance one by one in the tested reverse-chain order.",
    )

    clearance = sub.add_parser("clearance")
    clearance.add_argument("--joints", default=",".join(DEFAULT_CLEARANCE_ORDER))
    clearance.add_argument("--clearance-file", default=TABLE_CLEARANCE_PATH)
    clearance.add_argument("--seconds", type=float, default=5.0)
    clearance.add_argument("--kp", type=float, default=3.0)
    clearance.add_argument("--kd", type=float, default=0.3)
    clearance.add_argument("--deadband-deg", type=float, default=0.5)
    clearance.add_argument("--max-delta-deg", type=float, default=20.0)
    clearance.add_argument(
        "--step-deg",
        type=float,
        default=0.0,
        help="Split each clearance joint move into steps no larger than this many degrees. Use for large home-to-clearance moves.",
    )
    clearance.add_argument(
        "--parallel",
        action="store_true",
        help="Move selected clearance joints together on one continuous trajectory.",
    )
    clearance.add_argument(
        "--no-coupled-shoulder-group",
        dest="coupled_shoulder_group",
        action="store_false",
        default=True,
        help="Disable v2.2 coupled shoulder_front/shoulder_side/elbow clearance move and use sequential v2 behavior.",
    )
    clearance.add_argument(
        "--auto-gains",
        dest="auto_gains",
        action="store_true",
        default=True,
        help="Use verified per-joint home gains. This is the default.",
    )
    clearance.add_argument(
        "--no-auto-gains",
        dest="auto_gains",
        action="store_false",
        help="Use the uniform --kp/--kd/--seconds values instead.",
    )
    clearance.add_argument("--execute", action="store_true")

    return parser


def main() -> None:
    args = build_parser().parse_args()

    if args.cmd == "show-home":
        print(json.dumps(load_home(args.home_file), ensure_ascii=False, indent=2))
        return

    if args.cmd == "show-clearance":
        print(json.dumps(load_pose(args.clearance_file), ensure_ascii=False, indent=2))
        return

    if args.cmd == "show-claw-home":
        print(json.dumps(load_pose(args.claw_home_file), ensure_ascii=False, indent=2))
        return

    arm = LeftArmV2()
    try:
        print("Serial port is open")

        if args.cmd == "status":
            arm.print_status(parse_joints(args.joints))
            return

        if args.cmd == "restart":
            joints = parse_joints(args.joints)
            arm.validate(joints)
            if not args.execute:
                print("dry run only. Add --execute to disable and re-enable motors.")
                arm.print_status(joints)
                return
            arm.restart_motors(
                joints,
                off_seconds=args.off_seconds,
                hold_seconds=args.hold_seconds,
                hold_kp=args.hold_kp,
                hold_kd=args.hold_kd,
            )
            return

        if args.cmd == "hold":
            joints = parse_joints(args.joints)
            arm.enable(joints)
            arm.hold_current(joints, seconds=args.seconds, kp=args.kp, kd=args.kd)
            arm.print_status(joints)
            return

        if args.cmd == "capture-home":
            joints = parse_joints(args.joints)
            home = arm.positions(joints)
            save_home(home, note=args.note, path=args.home_file)
            return

        if args.cmd == "capture-clearance":
            joints = parse_joints(args.joints)
            pose = arm.positions(joints)
            save_pose("left_arm_v2_table_clearance", pose, note=args.note, path=args.clearance_file)
            return

        if args.cmd == "capture-claw-home":
            pose = {"claw": arm.claw_status()["pos"]}
            save_pose("left_arm_v2_claw_home", pose, note=args.note, path=args.claw_home_file)
            return

        if args.cmd == "claw-home":
            home = load_pose(args.claw_home_file)
            if "claw" not in home:
                raise RuntimeError("invalid claw home file: missing claw")
            if not args.execute:
                print("dry run only. Add --execute to move claw home.")
                print(json.dumps({"target": {"claw": home["claw"]}, "status": arm.claw_status()}, ensure_ascii=False, indent=2))
                return
            status = arm.claw_home(home["claw"])
            print(json.dumps({"target": {"claw": home["claw"]}, "status": status}, ensure_ascii=False, indent=2))
            return

        if args.cmd == "claw-close":
            home = load_pose(args.claw_home_file)
            if "claw" not in home:
                raise RuntimeError("invalid claw home file: missing claw")
            if not args.execute:
                print("dry run only. Add --execute to close claw.")
                print(
                    json.dumps(
                        {
                            "home": home["claw"],
                            "close_target": home["claw"] + args.close_offset,
                            "status": arm.claw_status(),
                        },
                        ensure_ascii=False,
                        indent=2,
                    )
                )
                return
            arm.claw_close_until_pressure(home["claw"], hold=not args.no_hold, close_offset=args.close_offset)
            return

        if args.cmd == "nudge":
            if abs(args.deg) > args.max_deg:
                raise ValueError(f"nudge deg exceeds --max-deg {args.max_deg}")
            joints = parse_joints(args.joint)
            arm.validate(joints)
            arm.enable(joints)
            starts = arm.positions(joints)
            targets = {name: starts[name] + math.radians(args.deg) for name in joints}
            print(
                "v2 nudge joints:",
                ", ".join(joints),
                "delta_deg=",
                args.deg,
                "kp=",
                args.kp,
                "kd=",
                args.kd,
            )
            print(json.dumps({"start": starts, "target": targets}, ensure_ascii=False, indent=2))
            if args.auto_gains:
                for name in joints:
                    gains = NUDGE_GAINS.get(name, {"kp": args.kp, "kd": args.kd})
                    print(
                        "v2 nudge auto gains",
                        name,
                        "kp=",
                        gains["kp"],
                        "kd=",
                        gains["kd"],
                        "seconds=",
                        args.seconds,
                    )
                arm.move_targets_auto_gains(
                    targets,
                    seconds=args.seconds,
                    gains=NUDGE_GAINS,
                    fallback_kp=args.kp,
                    fallback_kd=args.kd,
                )
            else:
                arm.move_targets(targets, seconds=args.seconds, kp=args.kp, kd=args.kd)
            arm.print_status(joints)
            return

        if args.cmd == "nudge-hold":
            if abs(args.deg) > args.max_deg:
                raise ValueError(f"nudge deg exceeds --max-deg {args.max_deg}")
            joints = parse_joints(args.joint)
            if len(joints) != 1:
                raise ValueError("nudge-hold expects exactly one --joint")
            name = joints[0]
            hold_names = [joint for joint in parse_joints(args.hold_joints) if joint != name]
            arm.validate([name] + hold_names)
            all_names = [name] + hold_names
            arm.enable(all_names)
            current = arm.positions(all_names)
            requested_target = current[name] + math.radians(args.deg)
            target = requested_target
            target_limits = NUDGE_TARGET_LIMITS.get(name)
            if target_limits:
                min_target = target_limits.get("min")
                max_target = target_limits.get("max")
                if min_target is not None and target < min_target:
                    target = min_target
                if max_target is not None and target > max_target:
                    target = max_target
                if target != requested_target:
                    print(
                        "v2.6 nudge-hold target clamped",
                        name,
                        "requested=",
                        requested_target,
                        "target=",
                        target,
                        "limits=",
                        json.dumps(target_limits, ensure_ascii=False),
                    )
            low_shoulder_front = is_low_shoulder_front(current)
            if args.auto_gains:
                if low_shoulder_front and name in NUDGE_LOW_SHOULDER_GAINS:
                    active_gains = NUDGE_LOW_SHOULDER_GAINS[name]
                elif name == "wrist":
                    active_gains = WRIST_ACTIVE_NUDGE_GAINS
                elif name == "wrist_side":
                    active_gains = CLEARANCE_HOLD_GAINS["wrist_side"]
                else:
                    active_gains = NUDGE_GAINS.get(name, {"kp": args.kp, "kd": args.kd})
                kp = active_gains["kp"]
                kd = active_gains["kd"]
                if name == "wrist":
                    args.seconds = max(args.seconds, WRIST_ACTIVE_NUDGE_MIN_SECONDS)
                if low_shoulder_front and name in NUDGE_LOW_SHOULDER_MIN_SECONDS:
                    args.seconds = max(args.seconds, NUDGE_LOW_SHOULDER_MIN_SECONDS[name])
                if name in NUDGE_MIN_SECONDS:
                    args.seconds = max(args.seconds, NUDGE_MIN_SECONDS[name])
            else:
                kp = args.kp
                kd = args.kd
            hold_targets = {joint: current[joint] for joint in hold_names}
            hold_gains = {
                joint: CLEARANCE_HOLD_GAINS.get(
                    joint,
                    CLEARANCE_BASE_HOLD_GAINS.get(joint, NUDGE_GAINS.get(joint, {"kp": args.kp, "kd": args.kd})),
                )
                for joint in hold_names
            }
            for compliant_name in CLEARANCE_COMPLIANT_HOLDS_BY_ACTIVE.get(name, set()):
                if compliant_name in hold_gains:
                    hold_gains[compliant_name] = CLEARANCE_COMPLIANT_HOLD_GAINS[compliant_name]
            nudge_compliant_gains = NUDGE_COMPLIANT_HOLD_GAINS_BY_ACTIVE.get(name, NUDGE_COMPLIANT_HOLD_GAINS)
            for compliant_name in NUDGE_COMPLIANT_HOLDS_BY_ACTIVE.get(name, set()):
                if compliant_name in hold_gains:
                    hold_gains[compliant_name] = nudge_compliant_gains[compliant_name]
            hold_gains = adaptive_hold_gains_for(name, hold_gains, low_shoulder_front)
            coupled_targets = {name: target}
            coupled_requested_targets = {name: requested_target}
            coupled_gains = {name: {"kp": kp, "kd": kd}}
            coupled_tau = {}
            for coupled_name, ratio in NUDGE_COUPLED_ACTIVE_RATIOS.get(name, {}).items():
                if coupled_name not in hold_targets:
                    continue
                coupled_requested = current[coupled_name] + math.radians(args.deg * ratio)
                coupled_targets[coupled_name] = coupled_requested
                coupled_requested_targets[coupled_name] = coupled_requested
                coupled_gains[coupled_name] = NUDGE_COUPLED_ACTIVE_GAINS.get(name, {}).get(
                    coupled_name,
                    COUPLED_CLEARANCE_MOVE_GAINS.get(
                        coupled_name,
                        NUDGE_GAINS.get(coupled_name, {"kp": args.kp, "kd": args.kd}),
                    ),
                )
                if coupled_name in NUDGE_HOLD_TAU and ratio > 0:
                    coupled_tau[coupled_name] = NUDGE_HOLD_TAU[coupled_name]
                hold_targets.pop(coupled_name, None)
                hold_gains.pop(coupled_name, None)
            nominal_hold_targets = dict(hold_targets)
            nudge_adaptive_active = f"{name}:{direction_key(args.deg)}"
            hold_tau = nudge_hold_tau_for(
                name,
                hold_targets,
                low_shoulder_front,
                adaptive_active=nudge_adaptive_active,
                use_adaptive=not args.no_adaptive_compensation,
            )
            hold_target_offsets = {} if args.no_adaptive_compensation else {
                hold_name: offset
                for hold_name, offset in adaptive_hold_target_bias_for(
                    nudge_adaptive_active,
                    hold_targets,
                    low_shoulder_front,
                ).items()
            }
            if args.no_adaptive_compensation:
                print("v2.6 nudge-hold learned compensation disabled for guarded probe")
            if hold_target_offsets:
                for hold_name, offset in hold_target_offsets.items():
                    hold_targets[hold_name] += offset
                print(
                    "v2.6 nudge-hold adaptive hold target bias=",
                    json.dumps({joint: math.degrees(offset) for joint, offset in hold_target_offsets.items()}, ensure_ascii=False),
                    "hold_targets=",
                    json.dumps({joint: hold_targets[joint] for joint in hold_target_offsets}, ensure_ascii=False),
                )
            active_tau = 0.0 if args.no_active_tau else nudge_active_tau_for(
                name, args.deg, low_shoulder_front
            )
            if active_tau and name in NUDGE_ACTIVE_TAU:
                coupled_tau[name] = active_tau
            print(
                "v2.6 nudge-hold active",
                name,
                "delta_deg=",
                args.deg,
                "kp=",
                kp,
                "kd=",
                kd,
                "seconds=",
                args.seconds,
                "hold joints:",
                ",".join(hold_names),
            )
            print(
                "v2.6 nudge-hold hold_tau=",
                json.dumps({joint: hold_tau[joint] for joint in hold_targets if joint in hold_tau}, ensure_ascii=False),
                "control_dt=",
                0.01,
            )
            if hold_tau.get("shoulder_front") != NUDGE_HOLD_TAU.get("shoulder_front"):
                print(
                    "v2.6 nudge-hold adjusted shoulder_front hold_tau=",
                    hold_tau["shoulder_front"],
                    "shoulder_front_pos=",
                    hold_targets.get("shoulder_front"),
                )
            active_tau = 0.0 if args.no_active_tau else nudge_active_tau_for(
                name, args.deg, low_shoulder_front
            )
            if active_tau:
                print("v2.6 nudge-hold active_tau=", {name: active_tau})
            if name in NUDGE_LOW_SHOULDER_GAINS and is_low_shoulder_front(current):
                print(
                    "v2.6 nudge-hold low shoulder gains active",
                    name,
                    "shoulder_front_pos=",
                    current.get("shoulder_front"),
                )
            low_shoulder_hold_overrides = {
                hold_name: hold_gains[hold_name]
                for hold_name in (
                    set(POSTURE_HOLD_GAIN_RULES[LOW_SHOULDER_POSTURE].get("*", {}))
                    | set(POSTURE_HOLD_GAIN_RULES[LOW_SHOULDER_POSTURE].get(name, {}))
                )
                if hold_name in hold_gains
            }
            if low_shoulder_hold_overrides and is_low_shoulder_front(current):
                print(
                    "v2.6 nudge-hold low shoulder adaptive hold gains=",
                    json.dumps(low_shoulder_hold_overrides, ensure_ascii=False),
                )
            preload_seconds = NUDGE_PRELOAD_SECONDS.get(name, 0.2)
            if preload_seconds != 0.2:
                print("v2.6 nudge-hold preload_seconds=", preload_seconds)
            trajectory = NUDGE_TRAJECTORY.get(name, "smoothstep")
            linear_blend = NUDGE_LINEAR_BLEND.get(name, 0.0)
            if trajectory != "smoothstep":
                print("v2.6 nudge-hold trajectory=", trajectory, "linear_blend=", linear_blend)
            compliant_holds = {
                joint: hold_gains[joint]
                for joint in NUDGE_COMPLIANT_HOLDS_BY_ACTIVE.get(name, set())
                if joint in hold_gains
            }
            if compliant_holds:
                print("v2.6 nudge-hold compliant hold gains=", json.dumps(compliant_holds, ensure_ascii=False))
            step_deg = NUDGE_STEP_DEG.get(name, 0.0)
            if step_deg > 0:
                print("v2.6 nudge-hold step_deg=", step_deg)
            if len(coupled_targets) > 1:
                print(
                    "v2.6 nudge-hold coupled active targets=",
                    json.dumps(coupled_targets, ensure_ascii=False),
                    "gains=",
                    json.dumps(coupled_gains, ensure_ascii=False),
                    "move_tau_ff=",
                    json.dumps(coupled_tau, ensure_ascii=False),
                )
            print(
                json.dumps(
                    {
                        "start": current,
                        "requested_target": coupled_requested_targets,
                        "target": coupled_targets,
                        "hold_targets": hold_targets,
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            if len(coupled_targets) > 1:
                arm.move_targets_with_holds(
                    coupled_targets,
                    seconds_per_step=args.seconds,
                    move_gains=coupled_gains,
                    hold_targets=hold_targets,
                    hold_gains=hold_gains,
                    fallback_kp=args.kp,
                    fallback_kd=args.kd,
                    hold_tau=hold_tau,
                    preload_seconds=preload_seconds,
                    control_dt=0.01,
                    move_tau_ff=coupled_tau,
                    trajectory=trajectory,
                    linear_blend=linear_blend,
                )
                arm.print_status(all_names)
                return
            hold_baseline_errors = {
                hold_name: math.degrees(nominal_hold_targets[hold_name] - current[hold_name])
                for hold_name in nominal_hold_targets
                if hold_name in current
            }
            arm.move_target_with_holds(
                name,
                target,
                seconds_per_step=args.seconds,
                kp=kp,
                kd=kd,
                hold_targets=hold_targets,
                hold_gains=hold_gains,
                fallback_kp=args.kp,
                fallback_kd=args.kd,
                hold_tau=hold_tau,
                active_tau=active_tau,
                step_deg=step_deg,
                control_dt=0.01,
                preload_seconds=preload_seconds,
                trajectory=trajectory,
                linear_blend=linear_blend,
                max_velocity=args.max_velocity,
                max_position_error_deg=args.max_position_error_deg,
                active_max_delta_deg=abs(args.deg),
            )
            if name == "wrist_side" and is_low_shoulder_front(current):
                wrist_side_pos = arm.positions([name])[name]
                wrist_side_delta_deg = math.degrees(target - wrist_side_pos)
                if abs(wrist_side_delta_deg) > NUDGE_LOW_SHOULDER_WRIST_SIDE_FINE_DEADBAND_DEG:
                    fine = NUDGE_LOW_SHOULDER_WRIST_SIDE_FINE_GAINS
                    fine_bias_deg = max(
                        -NUDGE_LOW_SHOULDER_WRIST_SIDE_FINE_MAX_BIAS_DEG,
                        min(NUDGE_LOW_SHOULDER_WRIST_SIDE_FINE_MAX_BIAS_DEG, wrist_side_delta_deg),
                    )
                    fine_target = target + math.radians(fine_bias_deg)
                    print(
                        "v2.6 nudge-hold low shoulder wrist_side fine",
                        "delta_deg=",
                        wrist_side_delta_deg,
                        "bias_deg=",
                        fine_bias_deg,
                        "target=",
                        fine_target,
                        "kp=",
                        fine["kp"],
                        "kd=",
                        fine["kd"],
                        "seconds=",
                        fine["seconds"],
                    )
                    arm.move_target_with_holds(
                        name,
                        fine_target,
                        seconds_per_step=fine["seconds"],
                        kp=fine["kp"],
                        kd=fine["kd"],
                        hold_targets=hold_targets,
                        hold_gains=hold_gains,
                        fallback_kp=args.kp,
                        fallback_kd=args.kd,
                        hold_tau=hold_tau,
                        active_tau=active_tau,
                        step_deg=0.0,
                        control_dt=0.01,
                        preload_seconds=0.1,
                        trajectory="smoothstep",
                        linear_blend=0.0,
                    )
                else:
                    print(
                        "v2.6 nudge-hold low shoulder wrist_side fine skip delta_deg=",
                        wrist_side_delta_deg,
                        "deadband_deg=",
                        NUDGE_LOW_SHOULDER_WRIST_SIDE_FINE_DEADBAND_DEG,
                    )
            arm.print_status(all_names)
            final_all_positions = arm.positions(all_names)
            active_error_deg = math.degrees(target - final_all_positions[name])
            if args.no_adaptive_learning:
                print("v2.6 nudge-hold adaptive learning disabled for guarded probe")
                return
            active_tau_updates = update_adaptive_active_tau(
                name,
                args.deg,
                active_error_deg,
                active_tau,
                low_shoulder_front=low_shoulder_front,
                label="nudge-hold-active",
            )
            if active_tau_updates:
                print(
                    "v2.6 nudge-hold adaptive active tau updates",
                    json.dumps(active_tau_updates, ensure_ascii=False),
                )
            final_positions = {
                hold_name: final_all_positions[hold_name]
                for hold_name in nominal_hold_targets
                if hold_name in final_all_positions
            }
            final_hold_errors = {
                hold_name: math.degrees(nominal_hold_targets[hold_name] - final_positions[hold_name])
                for hold_name in final_positions
            }
            applied_hold_errors = {
                hold_name: math.degrees(hold_targets[hold_name] - final_positions[hold_name])
                for hold_name in final_positions
                if hold_name in hold_targets
            }
            notable_applied_hold_errors = {
                hold_name: {
                    "nominal_error_deg": final_hold_errors[hold_name],
                    "applied_target_error_deg": applied_hold_errors[hold_name],
                    "hold_target_bias_deg": math.degrees(hold_targets[hold_name] - nominal_hold_targets[hold_name]),
                }
                for hold_name in applied_hold_errors
                if abs(hold_targets[hold_name] - nominal_hold_targets[hold_name]) > 1e-6
                or abs(applied_hold_errors[hold_name]) >= ADAPTIVE_TARGET_BIAS_ERROR_DEADBAND_DEG
            }
            if notable_applied_hold_errors:
                print(
                    "v2.6 nudge-hold hold error diagnostics",
                    json.dumps(notable_applied_hold_errors, ensure_ascii=False),
                )
            induced_errors = {
                hold_name: error
                for hold_name, error in final_hold_errors.items()
                if abs(hold_baseline_errors.get(hold_name, 0.0)) < ADAPTIVE_TARGET_BIAS_ERROR_DEADBAND_DEG
                and abs(error) >= ADAPTIVE_TARGET_BIAS_ERROR_DEADBAND_DEG
            }
            if induced_errors:
                print(
                    "v2.6 nudge-hold adaptive hold tau observation active-induced errors",
                    json.dumps(
                        {
                            hold_name: {
                                "before_active": hold_baseline_errors.get(hold_name, 0.0),
                                "final": final_hold_errors[hold_name],
                            }
                            for hold_name in induced_errors
                        },
                        ensure_ascii=False,
                    ),
                )
                hold_tau_updates = update_adaptive_hold_tau(
                    nudge_adaptive_active,
                    induced_errors,
                    hold_tau,
                    low_shoulder_front=low_shoulder_front,
                    label="nudge-hold-induced",
                    error_deadband_deg=ADAPTIVE_TARGET_BIAS_ERROR_DEADBAND_DEG,
                )
                if hold_tau_updates:
                    print(
                        "v2.6 nudge-hold adaptive hold tau updates",
                        json.dumps(hold_tau_updates, ensure_ascii=False),
                    )
                offset_ready_errors = {
                    hold_name: error
                    for hold_name, error in induced_errors.items()
                    if not hold_tau_update_waits_for_more_holding(hold_tau_updates.get(hold_name))
                }
                hold_tau_learning_errors = {
                    hold_name: error
                    for hold_name, error in induced_errors.items()
                    if hold_tau_update_waits_for_more_holding(hold_tau_updates.get(hold_name))
                }
                if hold_tau_learning_errors:
                    print(
                        "v2.6 nudge-hold adaptive hold target bias waiting for hold-tau learning",
                        json.dumps(hold_tau_learning_errors, ensure_ascii=False),
                    )
                if not offset_ready_errors:
                    return
                hold_target_updates = update_adaptive_hold_target_bias(
                    nudge_adaptive_active,
                    offset_ready_errors,
                    low_shoulder_front=low_shoulder_front,
                    label="nudge-hold-induced",
                )
                if hold_target_updates:
                    print(
                        "v2.6 nudge-hold adaptive hold target bias updates",
                        json.dumps(hold_target_updates, ensure_ascii=False),
                    )
            return

        if args.cmd == "home":
            home = load_home(args.home_file)
            ordered = [name for name in parse_joints(args.joints) if name in home]
            current = arm.positions(ordered)
            targets: Dict[str, float] = {}
            for name in ordered:
                delta_deg = math.degrees(home[name] - current[name])
                deadband_deg = max(args.deadband_deg, HOME_JOINT_DEADBANDS_DEG.get(name, args.deadband_deg))
                if abs(delta_deg) <= deadband_deg:
                    print("v2 home skip", name, "delta_deg=", delta_deg, "deadband_deg=", deadband_deg)
                    continue
                if abs(delta_deg) > args.max_delta_deg:
                    raise RuntimeError(
                        f"{name} home delta {delta_deg:.2f} deg exceeds --max-delta-deg {args.max_delta_deg}; "
                        "recapture home or move in smaller steps."
                    )
                targets[name] = home[name]
                print("v2 home target", name, "delta_deg=", delta_deg, "target=", home[name])

            if not targets:
                print("v2 home: all selected joints inside deadband; no motor enabled")
                arm.print_status(ordered)
                return

            if not args.execute:
                print("dry run only. Add --execute to move.")
                return

            if args.prehome_clearance:
                clearance = load_pose(args.clearance_file)
                prehome_order = [name for name in PREHOME_CLEARANCE_ORDER if name in clearance and name in DEFAULT_JOINTS]
                print("v2.6 pre-home clearance wrist-first coupled order=", ",".join(prehome_order))
                arm.enable(DEFAULT_JOINTS)
                wrist_name = "wrist"
                if wrist_name in prehome_order:
                    prehome_current = arm.positions(DEFAULT_JOINTS)
                    prehome_target = clearance[wrist_name]
                    delta_deg = math.degrees(prehome_target - prehome_current[wrist_name])
                    deadband_deg = max(0.5, CLEARANCE_JOINT_DEADBANDS_DEG.get(wrist_name, 0.5))
                    if abs(delta_deg) <= deadband_deg:
                        print(
                            "v2.6 pre-home clearance wrist-first skip",
                            wrist_name,
                            "delta_deg=",
                            delta_deg,
                            "deadband_deg=",
                            deadband_deg,
                        )
                    else:
                        if abs(delta_deg) > args.max_delta_deg:
                            raise RuntimeError(
                                f"{wrist_name} pre-home clearance delta {delta_deg:.2f} deg exceeds "
                                f"--max-delta-deg {args.max_delta_deg}; move in smaller steps."
                            )
                        active_gains = prehome_clearance_gains_for(wrist_name, args.kp, args.kd)
                        seconds = prehome_clearance_seconds_for(wrist_name, delta_deg)
                        hold_targets = {
                            hold_name: prehome_current[hold_name]
                            for hold_name in DEFAULT_JOINTS
                            if hold_name != wrist_name
                        }
                        hold_gains = prehome_clearance_hold_gains_for(
                            wrist_name,
                            hold_targets.keys(),
                            args.kp,
                            args.kd,
                        )
                        hold_tau = nudge_hold_tau_for(
                            wrist_name,
                            hold_targets,
                            is_low_shoulder_front(prehome_current),
                        )
                        active_tau = nudge_active_tau_for(
                            wrist_name,
                            delta_deg,
                            is_low_shoulder_front(prehome_current),
                        )
                        preload_seconds = NUDGE_PRELOAD_SECONDS.get(wrist_name, 0.2)
                        trajectory = NUDGE_TRAJECTORY.get(wrist_name, "smoothstep")
                        linear_blend = NUDGE_LINEAR_BLEND.get(wrist_name, 0.0)
                        print(
                            "v2.6 pre-home clearance wrist-first active",
                            wrist_name,
                            "delta_deg=",
                            delta_deg,
                            "target=",
                            prehome_target,
                            "kp=",
                            active_gains["kp"],
                            "kd=",
                            active_gains["kd"],
                            "seconds=",
                            seconds,
                            "hold joints:",
                            ",".join(hold_targets.keys()),
                        )
                        if active_tau:
                            print("v2.6 pre-home clearance wrist-first active_tau=", {wrist_name: active_tau})
                        entry_status=arm.read_status(list(hold_targets))
                        _,hold_tau,entry_audit=prehome_load_transfer(entry_status,{}, {},
                            hold_targets,hold_gains,args.kp,args.kd)
                        print('v2.6 pre-home entry support= '+json.dumps({
                            'stage':'wrist-first','joints':entry_audit,'learning_written':False}),flush=True)
                        print(
                            "v2.6 pre-home clearance wrist-first hold_tau=",
                            json.dumps({joint: hold_tau[joint] for joint in hold_targets if joint in hold_tau}, ensure_ascii=False),
                        )
                        arm.move_target_with_holds(
                            wrist_name,
                            prehome_target,
                            seconds_per_step=seconds,
                            kp=active_gains["kp"],
                            kd=active_gains["kd"],
                            hold_targets=hold_targets,
                            hold_gains=hold_gains,
                            fallback_kp=args.kp,
                            fallback_kd=args.kd,
                            hold_tau=hold_tau,
                            active_tau=active_tau,
                            control_dt=0.01,
                            preload_seconds=preload_seconds,
                            trajectory=trajectory,
                            linear_blend=linear_blend,
                        )

                prehome_current = arm.positions(DEFAULT_JOINTS)
                group_names = [name for name in prehome_order if name != wrist_name]
                group_targets: Dict[str, float] = {}
                group_gains: Dict[str, Dict[str, float]] = {}
                group_tau: Dict[str, float] = {}
                group_deltas_deg: Dict[str, float] = {}
                skipped_hold_targets: Dict[str, float] = {}
                group_seconds = 0.0
                low_shoulder = is_low_shoulder_front(prehome_current)
                for prehome_name in group_names:
                    prehome_target = clearance[prehome_name]
                    delta_deg = math.degrees(prehome_target - prehome_current[prehome_name])
                    group_deltas_deg[prehome_name] = delta_deg
                    deadband_deg = max(0.5, CLEARANCE_JOINT_DEADBANDS_DEG.get(prehome_name, 0.5))
                    if abs(delta_deg) <= deadband_deg:
                        print(
                            "v2.6 pre-home clearance coupled skip",
                            prehome_name,
                            "delta_deg=",
                            delta_deg,
                            "deadband_deg=",
                            deadband_deg,
                        )
                        skipped_hold_targets[prehome_name] = prehome_current[prehome_name]
                        continue
                    if abs(delta_deg) > args.max_delta_deg:
                        raise RuntimeError(
                            f"{prehome_name} pre-home clearance delta {delta_deg:.2f} deg exceeds "
                            f"--max-delta-deg {args.max_delta_deg}; move in smaller steps."
                        )
                    group_targets[prehome_name] = prehome_target
                    group_gains[prehome_name] = prehome_clearance_gains_for(prehome_name, args.kp, args.kd)
                    group_seconds = max(group_seconds, prehome_clearance_seconds_for(prehome_name, delta_deg))
                    active_tau = nudge_active_tau_for(prehome_name, delta_deg, low_shoulder)
                    if active_tau:
                        group_tau[prehome_name] = active_tau

                if group_targets:
                    hold_targets = {}
                    if wrist_name in clearance:
                        hold_targets[wrist_name] = clearance[wrist_name]
                    hold_targets.update(skipped_hold_targets)
                    hold_gains = prehome_clearance_hold_gains_for(
                        "wrist_side",
                        hold_targets.keys(),
                        args.kp,
                        args.kd,
                    )
                    hold_tau = nudge_hold_tau_for("wrist_side", hold_targets, low_shoulder)
                    entry_status=arm.read_status(list(group_targets)+list(hold_targets))
                    group_tau,hold_tau,entry_audit=prehome_load_transfer(entry_status,group_gains,group_tau,
                        hold_targets,hold_gains,args.kp,args.kd)
                    print('v2.6 pre-home entry support= '+json.dumps({
                        'stage':'coupled','joints':entry_audit,'learning_written':False}),flush=True)
                    print(
                        "v2.6 pre-home clearance coupled active",
                        ",".join(group_targets.keys()),
                        "deltas_deg=",
                        json.dumps(group_deltas_deg, ensure_ascii=False),
                        "targets=",
                        json.dumps(group_targets, ensure_ascii=False),
                        "seconds=",
                        group_seconds,
                        "hold joints:",
                        ",".join(hold_targets.keys()),
                    )
                    if group_tau:
                        print("v2.6 pre-home clearance coupled active_tau=", json.dumps(group_tau, ensure_ascii=False))
                    print(
                        "v2.6 pre-home clearance coupled hold_tau=",
                        json.dumps({joint: hold_tau[joint] for joint in hold_targets if joint in hold_tau}, ensure_ascii=False),
                    )
                    arm.move_targets_with_holds(
                        group_targets,
                        seconds_per_step=group_seconds,
                        move_gains=group_gains,
                        hold_targets=hold_targets,
                        hold_gains=hold_gains,
                        fallback_kp=args.kp,
                        fallback_kd=args.kd,
                        hold_tau=hold_tau,
                        move_tau_ff=group_tau,
                        control_dt=0.01,
                        preload_seconds=0.2,
                        trajectory="smoothstep",
                        linear_blend=0.0,
                    )
                else:
                    print("v2.6 pre-home clearance coupled: all non-wrist joints inside deadband")
                current = arm.positions(ordered)

            completed_targets: Dict[str, float] = {}
            for name in ordered:
                if name not in targets:
                    continue
                if name in completed_targets:
                    continue
                if name == "elbow" and "shoulder_front" in targets:
                    group_names = ["elbow", "shoulder_front"]
                    if "shoulder_side" in ordered and "shoulder_side" in home:
                        group_names.append("shoulder_side")
                    if "arm_roll" in targets:
                        group_names.append("arm_roll")
                    if "wrist_side" in targets:
                        group_names.append("wrist_side")
                    if "wrist" in targets:
                        group_names.append("wrist")
                    group_targets = {
                        group_name: targets.get(group_name, home[group_name])
                        for group_name in group_names
                    }
                    command_targets = dict(group_targets)
                    command_bias = {
                        group_name: math.radians(COUPLED_HOME_COMMAND_BIAS_DEG[group_name])
                        for group_name in group_names
                        if group_name in COUPLED_HOME_COMMAND_BIAS_DEG
                    }
                    for group_name, bias_rad in command_bias.items():
                        command_targets[group_name] += bias_rad
                    raw_seconds = max(HOME_GAINS.get(group_name, {"seconds": args.seconds})["seconds"] for group_name in group_names)
                    coupled_seconds = min(raw_seconds * 4.0, COUPLED_HOME_MAX_SECONDS)
                    hold_targets = {}
                    hold_gains = {}
                    for hold_name in ordered:
                        if hold_name in group_names:
                            continue
                        hold_targets[hold_name] = current[hold_name]
                        hold_gains[hold_name] = HOME_BASE_HOLD_GAINS.get(hold_name, {"kp": args.kp, "kd": args.kd})
                    move_gains = {
                        group_name: COUPLED_HOME_MOVE_GAINS.get(group_name, HOME_GAINS.get(group_name, {"kp": args.kp, "kd": args.kd}))
                        for group_name in group_names
                    }
                    print(
                        "v2.6 home coupled shoulder/roll/wrist active",
                        ",".join(group_names),
                        "hold joints:",
                        ", ".join(hold_targets.keys()),
                    )
                    for group_name in group_names:
                        gains = move_gains[group_name]
                        print("v2.6 home coupled shoulder/roll/wrist gains", group_name, "kp=", gains["kp"], "kd=", gains["kd"], "seconds=", coupled_seconds)
                    print("v2.6 home coupled shoulder/roll/wrist progress windows=", json.dumps(COUPLED_HOME_PROGRESS_WINDOWS, ensure_ascii=False))
                    if COUPLED_HOME_PRE_WINDOW_GAINS:
                        print("v2.6 home coupled shoulder/roll/wrist pre-window gains=", json.dumps(COUPLED_HOME_PRE_WINDOW_GAINS, ensure_ascii=False))
                    if command_bias:
                        print(
                            "v2.6 home coupled shoulder/roll/wrist command bias deg=",
                            json.dumps({name: COUPLED_HOME_COMMAND_BIAS_DEG[name] for name in command_bias}, ensure_ascii=False),
                        )
                    print("v2.6 home coupled shoulder/roll/wrist control_dt=", COUPLED_HOME_CONTROL_DT)
                    print("v2.6 home coupled shoulder/roll/wrist trajectory=", COUPLED_HOME_TRAJECTORY)
                    if COUPLED_HOME_TRAJECTORY == "blend_smootherstep":
                        print("v2.6 home coupled shoulder/roll/wrist linear_blend=", COUPLED_HOME_LINEAR_BLEND)
                    arm.enable(group_names + list(hold_targets.keys()))
                    arm.move_targets_with_holds(
                        command_targets,
                        seconds_per_step=coupled_seconds,
                        move_gains=move_gains,
                        hold_targets=hold_targets,
                        hold_gains=hold_gains,
                        fallback_kp=args.kp,
                        fallback_kd=args.kd,
                        step_deg=0.0,
                        progress_windows=COUPLED_HOME_PROGRESS_WINDOWS,
                        pre_window_gains=COUPLED_HOME_PRE_WINDOW_GAINS,
                        control_dt=COUPLED_HOME_CONTROL_DT,
                        trajectory=COUPLED_HOME_TRAJECTORY,
                        linear_blend=COUPLED_HOME_LINEAR_BLEND,
                    )
                    reached = arm.positions(group_names)
                    print("v2.6 home coupled shoulder/roll/wrist reached=", json.dumps(reached, ensure_ascii=False))
                    completed_targets.update(command_targets)
                    continue
                if args.auto_gains:
                    gains = HOME_GAINS.get(name, {"kp": args.kp, "kd": args.kd, "seconds": args.seconds})
                    kp = gains["kp"]
                    kd = gains["kd"]
                    seconds = gains["seconds"]
                    print("v2 home auto gains", name, "kp=", kp, "kd=", kd, "seconds=", seconds)
                else:
                    kp = args.kp
                    kd = args.kd
                    seconds = args.seconds
                hold_targets, hold_gains = home_hold_plan_for(name, ordered, current, completed_targets)
                print("v2 home active", name, "hold joints:", ", ".join(hold_targets.keys()))
                arm.enable([name] + list(hold_targets.keys()))
                arm.move_target_with_holds(
                    name,
                    targets[name],
                    seconds_per_step=seconds,
                    kp=kp,
                    kd=kd,
                    hold_targets=hold_targets,
                    hold_gains=hold_gains,
                    fallback_kp=args.kp,
                    fallback_kd=args.kd,
                    step_deg=0.0,
                )
                completed_targets[name] = targets[name]
            arm.print_status(ordered)
            return

        if args.cmd == "clearance":
            clearance = load_pose(args.clearance_file)
            ordered = [name for name in parse_joints(args.joints) if name in clearance]
            current = arm.positions(ordered)
            targets: Dict[str, float] = {}
            deltas_deg: Dict[str, float] = {}
            for name in ordered:
                delta_deg = math.degrees(clearance[name] - current[name])
                deadband_deg = max(args.deadband_deg, CLEARANCE_JOINT_DEADBANDS_DEG.get(name, args.deadband_deg))
                if abs(delta_deg) <= deadband_deg:
                    print("v2 clearance skip", name, "delta_deg=", delta_deg, "deadband_deg=", deadband_deg)
                    continue
                if abs(delta_deg) > args.max_delta_deg:
                    raise RuntimeError(
                        f"{name} clearance delta {delta_deg:.2f} deg exceeds --max-delta-deg {args.max_delta_deg}; "
                        "move in smaller steps or recapture clearance."
                    )
                targets[name] = clearance[name]
                deltas_deg[name] = delta_deg
                print("v2 clearance target", name, "delta_deg=", delta_deg, "target=", clearance[name])
                if name in CLEARANCE_CONTINUOUS_JOINTS:
                    print("v2 clearance planned continuous", name, "steps= 1")
                elif args.step_deg > 0:
                    effective_step_deg = args.step_deg
                    steps = int(math.ceil(abs(delta_deg) / effective_step_deg))
                    print("v2 clearance planned steps", name, "steps=", steps, "step_deg<=", effective_step_deg)

            if not targets:
                print("v2 clearance: all selected joints inside deadband; no motor enabled")
                arm.print_status(ordered)
                return

            if not args.execute:
                print("dry run only. Add --execute to move.")
                return

            if args.parallel:
                arm.enable(ordered)
                if args.step_deg > 0:
                    max_steps = max(int(math.ceil(abs(delta) / args.step_deg)) for delta in deltas_deg.values())
                else:
                    max_steps = 1
                total_seconds = args.seconds * max(1, max_steps)
                if args.auto_gains:
                    for name in ordered:
                        if name not in targets:
                            continue
                        gains = CLEARANCE_MOVE_GAINS.get(name, {"kp": args.kp, "kd": args.kd})
                        print(
                            "v2 clearance parallel auto gains",
                            name,
                            "kp=",
                            gains["kp"],
                            "kd=",
                            gains["kd"],
                        )
                    print("v2 clearance parallel seconds=", total_seconds, "steps=", max_steps)
                    arm.move_targets_auto_gains(
                        targets,
                        seconds=total_seconds,
                        gains=CLEARANCE_MOVE_GAINS,
                        fallback_kp=args.kp,
                        fallback_kd=args.kd,
                    )
                else:
                    print("v2 clearance parallel uniform gains kp=", args.kp, "kd=", args.kd, "seconds=", total_seconds)
                    arm.move_targets(targets, seconds=total_seconds, kp=args.kp, kd=args.kd)
                arm.print_status(ordered)
                return

            completed_targets: Dict[str, float] = {}
            for name in ordered:
                if name not in targets:
                    continue
                if name in completed_targets:
                    continue
                if (
                    args.coupled_shoulder_group
                    and name == "shoulder_front"
                    and "shoulder_side" in targets
                    and "elbow" in targets
                ):
                    group_names = ["shoulder_front", "shoulder_side", "elbow"]
                    if "arm_roll" in targets:
                        group_names.append("arm_roll")
                    if "wrist_side" in targets:
                        group_names.append("wrist_side")
                    if "wrist" in targets:
                        group_names.append("wrist")
                    group_targets = {group_name: targets[group_name] for group_name in group_names}
                    seconds = max(HOME_GAINS.get(group_name, {"seconds": args.seconds})["seconds"] for group_name in group_names)
                    if args.step_deg > 0:
                        coupled_steps = max(
                            int(math.ceil(abs(math.degrees(group_targets[group_name] - current[group_name])) / args.step_deg))
                            for group_name in group_names
                        )
                    else:
                        coupled_steps = 1
                    raw_coupled_seconds = seconds * max(1, coupled_steps)
                    coupled_seconds = min(raw_coupled_seconds, COUPLED_CLEARANCE_MAX_SECONDS)
                    hold_targets, hold_gains = clearance_hold_plan_for(
                        "shoulder_front",
                        ordered,
                        current,
                        completed_targets,
                    )
                    for group_name in group_names:
                        hold_targets.pop(group_name, None)
                        hold_gains.pop(group_name, None)
                    move_gains = {
                        group_name: COUPLED_CLEARANCE_MOVE_GAINS.get(group_name, CLEARANCE_MOVE_GAINS.get(group_name, {"kp": args.kp, "kd": args.kd}))
                        for group_name in group_names
                    }
                    print(
                        "v2.6 clearance coupled shoulder/roll/wrist active",
                        ",".join(group_names),
                        "hold joints:",
                        ", ".join(hold_targets.keys()),
                    )
                    for group_name in group_names:
                        gains = move_gains[group_name]
                        print("v2.6 clearance coupled shoulder/roll/wrist gains", group_name, "kp=", gains["kp"], "kd=", gains["kd"], "seconds=", coupled_seconds)
                    print(
                        "v2.6 clearance coupled shoulder/roll/wrist continuous interpolation steps_removed=",
                        coupled_steps,
                        "raw_seconds=",
                        raw_coupled_seconds,
                        "used_seconds=",
                        coupled_seconds,
                    )
                    print("v2.6 clearance coupled shoulder/roll/wrist progress windows=", json.dumps(COUPLED_CLEARANCE_PROGRESS_WINDOWS, ensure_ascii=False))
                    print("v2.6 clearance coupled shoulder/roll/wrist pre-window gains=", json.dumps(COUPLED_CLEARANCE_PRE_WINDOW_GAINS, ensure_ascii=False))
                    print("v2.6 clearance coupled shoulder/roll/wrist velocity_ff_joints=", ",".join(sorted(COUPLED_CLEARANCE_VELOCITY_FF_JOINTS)))
                    print("v2.6 clearance coupled shoulder/roll/wrist move_tau_ff=", json.dumps(COUPLED_CLEARANCE_MOVE_TAU_FF, ensure_ascii=False))
                    print("v2.6 clearance coupled shoulder/roll/wrist control_dt=", COUPLED_CLEARANCE_CONTROL_DT)
                    print("v2.6 clearance coupled shoulder/roll/wrist trajectory=", COUPLED_CLEARANCE_TRAJECTORY)
                    if COUPLED_CLEARANCE_TRAJECTORY == "blend_smootherstep":
                        print("v2.6 clearance coupled shoulder/roll/wrist linear_blend=", COUPLED_CLEARANCE_LINEAR_BLEND)
                    arm.enable(group_names + list(hold_targets.keys()))
                    arm.move_targets_with_holds(
                        group_targets,
                        seconds_per_step=coupled_seconds,
                        move_gains=move_gains,
                        hold_targets=hold_targets,
                        hold_gains=hold_gains,
                        fallback_kp=args.kp,
                        fallback_kd=args.kd,
                        hold_tau=CLEARANCE_JOINT_HOLD_TAU,
                        step_deg=0.0,
                        progress_windows=COUPLED_CLEARANCE_PROGRESS_WINDOWS,
                        pre_window_gains=COUPLED_CLEARANCE_PRE_WINDOW_GAINS,
                        control_dt=COUPLED_CLEARANCE_CONTROL_DT,
                        velocity_ff_joints=COUPLED_CLEARANCE_VELOCITY_FF_JOINTS,
                        move_tau_ff=COUPLED_CLEARANCE_MOVE_TAU_FF,
                        trajectory=COUPLED_CLEARANCE_TRAJECTORY,
                        linear_blend=COUPLED_CLEARANCE_LINEAR_BLEND,
                    )
                    time.sleep(COUPLED_CLEARANCE_SETTLE_SECONDS)
                    reached = arm.positions(group_names)
                    print("v2.6 clearance coupled shoulder/roll/wrist reached=", json.dumps(reached, ensure_ascii=False))
                    if "wrist" in group_names:
                        wrist_delta_deg = math.degrees(group_targets["wrist"] - reached["wrist"])
                        if abs(wrist_delta_deg) > CLEARANCE_WRIST_FINE_DEADBAND_DEG:
                            fine = COUPLED_CLEARANCE_WRIST_FINE_GAINS
                            fine_bias_deg = max(
                                -CLEARANCE_WRIST_FINE_MAX_BIAS_DEG,
                                min(CLEARANCE_WRIST_FINE_MAX_BIAS_DEG, wrist_delta_deg),
                            )
                            fine_target = group_targets["wrist"] + math.radians(fine_bias_deg)
                            fine_hold_targets = dict(hold_targets)
                            fine_hold_targets.update(
                                {
                                    group_name: group_targets[group_name]
                                    for group_name in group_names
                                    if group_name != "wrist"
                                }
                            )
                            fine_hold_gains = dict(hold_gains)
                            for group_name in group_names:
                                if group_name != "wrist":
                                    fine_hold_gains[group_name] = CLEARANCE_HOLD_GAINS.get(
                                        group_name,
                                        CLEARANCE_BASE_HOLD_GAINS[group_name],
                                    )
                            for compliant_name in CLEARANCE_COMPLIANT_HOLDS_BY_ACTIVE.get("wrist", set()):
                                if compliant_name in fine_hold_gains:
                                    fine_hold_gains[compliant_name] = CLEARANCE_COMPLIANT_HOLD_GAINS[compliant_name]
                            print("v2.6 clearance coupled wrist fine hold gains=", json.dumps(fine_hold_gains, ensure_ascii=False))
                            if CLEARANCE_WRIST_FINE_SETTLE_SECONDS > 0:
                                settle_targets = dict(fine_hold_targets)
                                settle_targets["wrist"] = group_targets["wrist"]
                                settle_gains = dict(fine_hold_gains)
                                settle_gains["wrist"] = CLEARANCE_HOLD_GAINS["wrist"]
                                print("v2.6 clearance coupled wrist settle before fine seconds=", CLEARANCE_WRIST_FINE_SETTLE_SECONDS)
                                arm.hold_positions_with_gains(
                                    settle_targets,
                                    seconds=CLEARANCE_WRIST_FINE_SETTLE_SECONDS,
                                    gains=settle_gains,
                                    fallback_kp=args.kp,
                                    fallback_kd=args.kd,
                                    hold_tau=CLEARANCE_JOINT_HOLD_TAU,
                                )
                            print(
                                "v2.6 clearance coupled wrist fine target delta_deg=",
                                wrist_delta_deg,
                                "bias_deg=",
                                fine_bias_deg,
                                "target=",
                                fine_target,
                                "kp=",
                                fine["kp"],
                                "kd=",
                                fine["kd"],
                                "seconds=",
                                fine["seconds"],
                            )
                            arm.move_target_with_holds(
                                "wrist",
                                fine_target,
                                seconds_per_step=fine["seconds"],
                                kp=fine["kp"],
                                kd=fine["kd"],
                                hold_targets=fine_hold_targets,
                                hold_gains=fine_hold_gains,
                                fallback_kp=args.kp,
                                fallback_kd=args.kd,
                                hold_tau=CLEARANCE_JOINT_HOLD_TAU,
                                active_tau=CLEARANCE_WRIST_FINE_ACTIVE_TAU,
                                control_dt=CLEARANCE_WRIST_FINE_CONTROL_DT,
                                active_velocity_ff=False,
                                step_deg=0.0,
                            )
                        else:
                            print(
                                "v2.6 clearance coupled wrist fine skip delta_deg=",
                                wrist_delta_deg,
                                "deadband_deg=",
                                CLEARANCE_WRIST_FINE_DEADBAND_DEG,
                            )
                    completed_targets.update(group_targets)
                    continue
                if args.auto_gains:
                    gains = CLEARANCE_MOVE_GAINS.get(name, {"kp": args.kp, "kd": args.kd})
                    kp = gains["kp"]
                    kd = gains["kd"]
                    seconds = CLEARANCE_MOVE_SECONDS.get(
                        name,
                        HOME_GAINS.get(name, {"seconds": args.seconds})["seconds"],
                    )
                    print("v2 clearance auto gains", name, "kp=", kp, "kd=", kd, "seconds=", seconds)
                else:
                    kp = args.kp
                    kd = args.kd
                    seconds = args.seconds
                hold_targets, hold_gains = clearance_hold_plan_for(name, ordered, current, completed_targets)
                print("v2 clearance active", name, "hold joints:", ", ".join(hold_targets.keys()))
                arm.enable([name] + list(hold_targets.keys()))
                arm.move_target_with_holds(
                    name,
                    targets[name],
                    seconds_per_step=seconds,
                    kp=kp,
                    kd=kd,
                    hold_targets=hold_targets,
                    hold_gains=hold_gains,
                    fallback_kp=args.kp,
                    fallback_kd=args.kd,
                    hold_tau=CLEARANCE_JOINT_HOLD_TAU,
                    active_velocity_ff=name in CLEARANCE_VELOCITY_FF_JOINTS,
                    step_deg=0.0 if name in CLEARANCE_CONTINUOUS_JOINTS else args.step_deg,
                )
                if name == "wrist":
                    if CLEARANCE_WRIST_FINE_SETTLE_SECONDS > 0:
                        settle_targets = dict(hold_targets)
                        settle_targets[name] = targets[name]
                        settle_gains = dict(hold_gains)
                        settle_gains[name] = CLEARANCE_HOLD_GAINS[name]
                        print("v2.6 clearance wrist settle before fine seconds=", CLEARANCE_WRIST_FINE_SETTLE_SECONDS)
                        arm.hold_positions_with_gains(
                            settle_targets,
                            seconds=CLEARANCE_WRIST_FINE_SETTLE_SECONDS,
                            gains=settle_gains,
                            fallback_kp=args.kp,
                            fallback_kd=args.kd,
                            hold_tau=CLEARANCE_JOINT_HOLD_TAU,
                        )
                    wrist_pos = arm.positions([name])[name]
                    wrist_delta_deg = math.degrees(targets[name] - wrist_pos)
                    if abs(wrist_delta_deg) > CLEARANCE_WRIST_FINE_DEADBAND_DEG:
                        fine = CLEARANCE_WRIST_FINE_GAINS
                        fine_bias_deg = max(
                            -CLEARANCE_WRIST_FINE_MAX_BIAS_DEG,
                            min(CLEARANCE_WRIST_FINE_MAX_BIAS_DEG, wrist_delta_deg),
                        )
                        fine_target = targets[name] + math.radians(fine_bias_deg)
                        print(
                            "v2.6 clearance wrist fine target delta_deg=",
                            wrist_delta_deg,
                            "bias_deg=",
                            fine_bias_deg,
                            "target=",
                            fine_target,
                            "kp=",
                            fine["kp"],
                            "kd=",
                            fine["kd"],
                            "seconds=",
                            fine["seconds"],
                        )
                        arm.move_target_with_holds(
                            name,
                            fine_target,
                            seconds_per_step=fine["seconds"],
                            kp=fine["kp"],
                            kd=fine["kd"],
                            hold_targets=hold_targets,
                            hold_gains=hold_gains,
                            fallback_kp=args.kp,
                            fallback_kd=args.kd,
                            hold_tau=CLEARANCE_JOINT_HOLD_TAU,
                            active_tau=CLEARANCE_WRIST_FINE_ACTIVE_TAU,
                            control_dt=CLEARANCE_WRIST_FINE_CONTROL_DT,
                            active_velocity_ff=False,
                            step_deg=0.0,
                        )
                    else:
                        print(
                            "v2.6 clearance wrist fine skip delta_deg=",
                            wrist_delta_deg,
                            "deadband_deg=",
                            CLEARANCE_WRIST_FINE_DEADBAND_DEG,
                        )
                completed_targets[name] = targets[name]
            arm.print_status(ordered)
            return

    finally:
        arm.close()


if __name__ == "__main__":
    main()
